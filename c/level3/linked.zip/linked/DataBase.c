#include <windows.h>
#include <string.h>
#include "fio.h"
#include "DataBase.h"


HANDLE DataHeap;
PROGINFO Info;
LPNODE dBase;

BOOL CreateBase ()
{
	DataHeap = HeapCreate(0, 1024, 0);
	if(DataHeap == NULL)
	{
		return FALSE;
	}
	
	dBase = HeapAlloc(DataHeap, 0, sizeof ( dBase ));
	if(dBase == NULL) return FALSE;
	dBase->Next = NULL;
	dBase->Prev = NULL;
	dBase->NoAvil = 1;
	Info.TotalRec = 0;
	Info.CurRec = 0;
	return TRUE;
}

BOOL DestroyBase ()
{
	if(DataHeap != NULL)
	{
		HeapDestroy(DataHeap);
		Info.TotalRec = 0;
		Info.CurRec = 0;
		return TRUE;
	}
	else
		return FALSE;
}

BOOL AddRecord (RECORD rec)
{
	LPNODE tmp;
	tmp = dBase;
	
//	if(Info.TotalRec != 0)
//	{
		tmp->Next = HeapAlloc (DataHeap, 0, sizeof ( NODE ));
	
		if(tmp->Next == NULL)
		{
			return FALSE;
		}
	
		tmp = tmp->Next;
		tmp->Prev = dBase;
		tmp->Next = NULL;
		dBase = tmp;
		Info.CurRec++;
		Info.TotalRec++;
//	}
	
	strcpy(dBase->rec.Name, rec.Name);
	strcpy(dBase->rec.Address, rec.Address);
	strcpy(dBase->rec.Address2, rec.Address2);
	strcpy(dBase->rec.city, rec.city);
	strcpy(dBase->rec.country, rec.country);
	strcpy(dBase->rec.postcode, rec.postcode);
	
	dBase->rec.omit = rec.omit;
	
	strcpy(dBase->rec.Telephone, rec.Telephone);
	strcpy(dBase->rec.Telephone2, rec.Telephone2);
	strcpy(dBase->rec.Fax, rec.Fax);
	strcpy(dBase->rec.Email, rec.Email);
	strcpy(dBase->rec.Web, rec.Web);
	
	if(Info.TotalRec == 0)
	{
		Info.TotalRec++;
	}

	if(Info.CurRec == 0)
	{
		Info.CurRec++;
	}

	return TRUE;
}

BOOL DelRecord ()
{
	LPNODE tmp;
	BOOL RetVal;

	tmp = dBase;
	
	dBase = tmp->Prev;
	
	
	if(tmp->Next != NULL )
	{
		dBase->Next = tmp->Next;
		dBase->Next->Prev = dBase;
	}
	else
		dBase->Next = NULL;
	
	RetVal = HeapFree ( DataHeap, 0, tmp );

	Info.TotalRec--;
	Info.CurRec--;

	if(RetVal == FALSE)
	{
		return FALSE;
	}	
		
	return TRUE;
}

void SaveRecord (RECORD rec)
{
	strcpy(dBase->rec.Name, rec.Name);
	strcpy(dBase->rec.Address, rec.Address);
	strcpy(dBase->rec.Address2, rec.Address2);
	strcpy(dBase->rec.city, rec.city);
	strcpy(dBase->rec.country, rec.country);
	strcpy(dBase->rec.postcode, rec.postcode);
	
	dBase->rec.omit = rec.omit;
	
	strcpy(dBase->rec.Telephone, rec.Telephone);
	strcpy(dBase->rec.Telephone2, rec.Telephone2);
	strcpy(dBase->rec.Fax, rec.Fax);
	strcpy(dBase->rec.Email, rec.Email);
	strcpy(dBase->rec.Web, rec.Web);
	return;
}

void NextRecord ()
{
	if( dBase->Next != NULL)
	{
		dBase = dBase->Next;
		Info.CurRec++;
	}
}

void PrevRecord ()
{
	if( (dBase->Prev != NULL) && (dBase->Prev->NoAvil != 1))
	{
		dBase = dBase->Prev;
		Info.CurRec--;
	}
}

RECORD ReturnBlankRecord()
{
	RECORD rec;

	strcpy(rec.Name, "");
	strcpy(rec.Address, "");
	strcpy(rec.Address2, "");
	strcpy(rec.city, "");
	strcpy(rec.country, "");
	strcpy(rec.postcode, "");
	
	rec.omit = 0;
	
	strcpy(rec.Telephone, "");
	strcpy(rec.Telephone2, "");
	strcpy(rec.Fax, "");
	strcpy(rec.Email, "");
	strcpy(rec.Web, "");

	return rec;
}
RECORD ReturnRecord ()
{
	if(DataHeap != NULL)
		return dBase->rec;
	else
		return dBase->rec;
}

BOOL OpenDataBase (char * szFilename)
{
	RECORD tmp;
	int Elements;
	BOOL er;

	er = DestroyBase();
//	if(er == FALSE) return FALSE;
	er = CreateBase();
	if(er == FALSE) return FALSE;

	Elements = OpenRecordFile ( szFilename, "r" ); //Redo to check for existing filenames
	
	if(Elements == -1)
	{
		return FALSE;
	}

	while (EnumRecords(&tmp) == TRUE)
	{
		AddRecord(tmp);
	}	
//	AddRecord (tmp);

	CloseRecordFile();
	Info.TotalRec = (Elements);
	Info.CurRec = (Elements);
	ReturnToZero();
	return TRUE;
}

void ReturnToZero ()
{
	while ((dBase->Prev  != NULL) && (dBase->Prev->NoAvil != 1))
	{
		PrevRecord();
	}
}

void SaveDataBase (char * szFilename)
{
	RECORD tmp;
	RECORDHEADER rech;
	int Elements;

	//while ((dBase->Prev  != NULL) && (dBase->Prev->NoAvil != 1))
	//{
	//	PrevRecord();
	//}
	ReturnToZero();
	Elements = OpenRecordFile ( szFilename, "w");

	if(Elements == -1)
	{
		return;
	}

	rech.id[0] = 'E';
	rech.id[1] = 'M';

	rech.NoRec = Info.TotalRec;

	WriteRecordHeader(&rech);
	
	//tmp = ReturnRecord();
	//WriteRecord(&tmp);			
	
	if(dBase->Next == NULL)
	//(Info.TotalRec == 1) 
	{
			tmp = ReturnRecord();
			WriteRecord(&tmp);		
	}
	else
	{
		do
			{			
				if(dBase->Next->Next == NULL)
				{
					tmp = ReturnRecord();
					WriteRecord(&tmp);		
					NextRecord();
					tmp = ReturnRecord();
					WriteRecord(&tmp);		
					break;
				}
				tmp = ReturnRecord();
				WriteRecord(&tmp);		
				NextRecord();	
			} while( 1 );
	}

	CloseRecordFile();

	return;
}

void ReturnDBInfo (int * t, int * c)
{
	*t = Info.TotalRec;
	*c = Info.CurRec;
	return;
}
