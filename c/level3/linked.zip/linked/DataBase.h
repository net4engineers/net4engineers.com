#include "fio.h"

#ifndef DATABASE_H
#define DATABASE_H

typedef struct tgNODE {
	struct tgNODE * Next;
	struct tgNODE * Prev;
	int NoAvil;
	RECORD rec;
}NODE, *LPNODE;

typedef struct tgPROGINFO {
	int TotalRec;
	int CurRec;
}PROGINFO;

BOOL CreateBase ();
BOOL DestroyBase ();

BOOL OpenDataBase (char * szFilename);
void SaveDataBase (char * szFilename);

void PrevRecord ();
void NextRecord ();
void ReturnToZero ();

BOOL AddRecord (RECORD rec);
BOOL DelRecord ();

void SaveRecord (RECORD rec);

RECORD ReturnRecord ();
RECORD ReturnBlankRecord();
void ReturnDBInfo (int * t, int * c);

#endif /* DATABASE_H */