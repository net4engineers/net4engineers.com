//
// Printing stuff.
// Bare bones printing, later add to it.

#include "Printing.h"
#include <string.h>

BOOL bname = TRUE;
BOOL baddress = TRUE;
BOOL baddress2 = TRUE;
BOOL bcity = TRUE;
BOOL bcountry = FALSE;
BOOL bpostcode = TRUE;
BOOL btelephone = FALSE;
BOOL btelephone2 = FALSE;
BOOL bfax = FALSE;
BOOL bemail = FALSE;
BOOL bweb = FALSE;
BOOL bcanceled = FALSE;

BOOL CALLBACK PrintDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch (iMsg)
	{
		case WM_INITDIALOG :
			if(bname) CheckDlgButton(hDlg, IDC_CH_NAME, 1);
			if(baddress) CheckDlgButton(hDlg, IDC_CH_ADDRESS, 1);
			if(baddress2) CheckDlgButton(hDlg, IDC_CH_ADDRESS2, 1);
			if(bcity) CheckDlgButton(hDlg, IDC_CH_CITY, 1);
			if(bcountry) CheckDlgButton(hDlg, IDC_CH_COUNTRY, 1);
			if(bpostcode) CheckDlgButton(hDlg, IDC_CH_POSTCODE, 1);
			if(btelephone) CheckDlgButton(hDlg, IDC_CH_TELEPHONE, 1);
			if(btelephone2) CheckDlgButton(hDlg, IDC_CH_TELEPHONE2, 1);
			if(bfax) CheckDlgButton(hDlg, IDC_CH_FAX, 1);
			if(bemail) CheckDlgButton(hDlg, IDC_CH_EMAIL, 1);
			if(bweb) CheckDlgButton(hDlg, IDC_CH_WEB, 1);

			SetWindowText (hDlg, "Print Options");
			break;
		case WM_COMMAND :
			switch(LOWORD(wParam))
			{
				case IDCANCEL :
					bcanceled = TRUE;
					EndDialog (hDlg, 1);
					break;
				case IDOK :
			if(IsDlgButtonChecked(hDlg, IDC_CH_NAME) == BST_CHECKED) 
				bname = TRUE;
			else
				bname = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_ADDRESS) == BST_CHECKED)
				baddress = TRUE;
			else
				baddress = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_ADDRESS2) == BST_CHECKED) 
				baddress2 = TRUE;
			else
				baddress2 = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_CITY) == BST_CHECKED) 
				bcity = TRUE;
			else
				bcity = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_COUNTRY) == BST_CHECKED) 
				bcountry = TRUE;
			else
				bcountry = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_POSTCODE) == BST_CHECKED) 
				bpostcode = TRUE;
			else
				bpostcode = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_TELEPHONE) == BST_CHECKED)			
				btelephone = TRUE;
			else
				btelephone = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_TELEPHONE2) == BST_CHECKED)
				btelephone2 = TRUE;
			else
				btelephone2 = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_FAX) == BST_CHECKED)
				bfax = TRUE;
			else
				bfax = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_EMAIL) == BST_CHECKED)
				bemail = TRUE;
			else
				bemail = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_WEB) == BST_CHECKED)
				bweb = TRUE;
			else
				bweb = FALSE;
					
			EndDialog (hDlg, 1);
		
			break;
			}
		}
	return FALSE;
}

BOOL Print (HINSTANCE hInst, HWND hwnd, LPRECORD rec , char * fname)
{
	HDC hdcPrint = GetPrinterDC ();
	static DOCINFO di;
	int ctr;
	TEXTMETRIC tm;
	int cxChar, cyChar;	
	char buffer[30];

	di.cbSize = sizeof (DOCINFO);
	di.lpszDocName = fname;
	di.lpszOutput = NULL;

	DialogBox(hInst, MAKEINTRESOURCE(IDD_OPTIONDIALOG), hwnd, PrintDlgProc);
	
	SaveDC ( hdcPrint );

	SetMapMode ( hdcPrint, MM_TEXT );
	
	if(StartDoc (hdcPrint, &di) > 0)
	{				
		ctr = StartPage (hdcPrint );
		if(ctr <= 0)
		{
			wsprintf(buffer, "Error on StartPage: code: %d", GetLastError());
			MessageBox ( NULL, buffer, "Error", MB_OK);
			return FALSE;
		}
		
		GetTextMetrics (hdcPrint, &tm);
		cxChar = tm.tmAveCharWidth;
		cyChar = tm.tmHeight;
		ctr = 0;

		if(bname)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Name,  strlen ( rec->Name ));
			ctr++;
		}

	    if(baddress)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Address, strlen ( rec->Address ));
			ctr++;
		}

		if(baddress2)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Address2, strlen ( rec->Address2 ));
			ctr++;
		}

		if(bcity)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->city, strlen ( rec->city ));
			ctr++;
		}

		if(bcountry)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->country, strlen ( rec->country ));
			ctr++;
		}

		if(bpostcode)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->postcode, strlen ( rec->postcode ));
			ctr++;
		}

		if(btelephone)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Telephone, strlen (rec->Telephone ));
			ctr++;
		}

		if(btelephone2)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Telephone2, strlen (rec->Telephone ));
			ctr++;
		}

		if(bfax)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Fax, strlen ( rec->Fax ));
			ctr++;
		}

		if(bemail)
		{
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Email, strlen ( rec->Email ));
			ctr++;
		}

		if(bweb)
		{   
			TextOut ( hdcPrint, 0, ctr * cyChar, rec->Web, strlen ( rec->Web ));
			ctr++;
		}

		ctr = EndPage(hdcPrint);
		if(ctr <= 0)
		{
			wsprintf(buffer, "Error on EndPage: code: %d", GetLastError());
			MessageBox ( NULL, buffer, "Error", MB_OK);
			return FALSE;
		}
		
		ctr = EndDoc (hdcPrint);
		if(ctr <= 0)
		{
			wsprintf(buffer, "Error on EndDoc: code: %d", GetLastError());
			MessageBox ( NULL, buffer, "Error", MB_OK);
			return FALSE;
		}
		
		RestoreDC (hdcPrint, -1);
		DeleteDC (hdcPrint);
		return TRUE;
	}
	wsprintf(buffer, "Error on StartDoc: code: %d", GetLastError());
	MessageBox ( NULL, buffer, "Error", MB_OK);
	return FALSE;
}

BOOL PrintRange (int * MyArg)
{
	int CRec, TRec;

	ReturnDBInfo(&TRec, &CRec);
	return FALSE;
}


BOOL PrintRec ( LPRECORD rec )
{
	HDC hdcPrint = GetPrinterDC ();
	static DOCINFO di = { sizeof (DOCINFO), "DGB Printing", NULL } ;		
	int ctr;
	TEXTMETRIC tm;
	int cxChar, cyChar;	
	char buffer[30];

	if(hdcPrint == NULL)
		return FALSE;

	SaveDC ( hdcPrint );

	SetMapMode ( hdcPrint, MM_TEXT );
	
	if(StartDoc (hdcPrint, &di) > 0)
	{
				
		ctr = StartPage (hdcPrint );
		if(ctr <= 0)
		{
			wsprintf(buffer, "Error on StartPage: code: %d", GetLastError());
			MessageBox ( NULL, buffer, "Error", MB_OK);
			return FALSE;
		}
		
		GetTextMetrics (hdcPrint, &tm);
		cxChar = tm.tmAveCharWidth;
		cyChar = tm.tmHeight;

		    TextOut ( hdcPrint, 0, 0, rec->Name,  strlen ( rec->Name ));
	        TextOut ( hdcPrint, 0, cyChar, rec->Address, strlen ( rec->Address ));
		TextOut ( hdcPrint, 0, 2 * cyChar, rec->Address2, strlen ( rec->Address2 ));
		TextOut ( hdcPrint, 0, 3 * cyChar, rec->city, strlen ( rec->city ));

		if(rec->omit == 0)
		{			
			 TextOut ( hdcPrint, 0, 4 * cyChar, rec->country, strlen ( rec->country ));
			 TextOut ( hdcPrint, 0, 5 * cyChar, rec->postcode, strlen ( rec->postcode ));
		
			 TextOut ( hdcPrint, 0, 7 * cyChar, rec->Telephone, strlen (rec->Telephone ));
			 TextOut ( hdcPrint, 0, 8 * cyChar, rec->Telephone2, strlen (rec->Telephone ));
			 TextOut ( hdcPrint, 0, 9 * cyChar, rec->Fax, strlen  ( rec->Fax ));
			TextOut ( hdcPrint, 0, 10 * cyChar, rec->Email, strlen ( rec->Email ));
			TextOut ( hdcPrint, 0, 11 * cyChar, rec->Web, strlen ( rec->Web ));
		}
		else
		{
			 TextOut ( hdcPrint, 0, 4 * cyChar, rec->postcode, strlen ( rec->postcode ));
	     
			 TextOut ( hdcPrint, 0, 6 * cyChar, rec->Telephone, strlen (rec->Telephone ));
			 TextOut ( hdcPrint, 0, 7 * cyChar, rec->Telephone2, strlen (rec->Telephone ));
			 TextOut ( hdcPrint, 0, 8 * cyChar, rec->Fax, strlen ( rec->Fax ));
			 TextOut ( hdcPrint, 0, 9 * cyChar, rec->Email, strlen ( rec->Email ));
			TextOut ( hdcPrint, 0, 10 * cyChar, rec->Web, strlen ( rec->Web ));
			
		}
	
		ctr = EndPage(hdcPrint);
		if(ctr <= 0)
		{
			wsprintf(buffer, "Error on EndPage: code: %d", GetLastError());
			MessageBox ( NULL, buffer, "Error", MB_OK);
			return FALSE;
		}
		
		ctr = EndDoc (hdcPrint);
		if(ctr <= 0)
		{
			wsprintf(buffer, "Error on EndDoc: code: %d", GetLastError());
			MessageBox ( NULL, buffer, "Error", MB_OK);
			return FALSE;
		}
		
		RestoreDC (hdcPrint, -1);
		DeleteDC (hdcPrint);
		return TRUE;
	}
	wsprintf(buffer, "Error on StartDoc: code: %d", GetLastError());
	MessageBox ( NULL, buffer, "Error", MB_OK);
	return FALSE;
}

HDC GetPrinterDC (void)
{
	PRINTER_INFO_5 pinfo5[5] ;
	DWORD dwNeeded, dwReturned ;

	if (EnumPrinters (PRINTER_ENUM_DEFAULT, NULL, 5, (LPBYTE) pinfo5,
		sizeof (pinfo5), &dwNeeded, &dwReturned))
		return CreateDC (NULL, pinfo5[0].pPrinterName, NULL, NULL) ;

	return 0 ;
}
