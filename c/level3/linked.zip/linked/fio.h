#include <windows.h>
#ifndef FIO_H
#define FIO_H

#define NAMESIZE 62
#define ADDRESSSIZE 62
#define CITYSIZE 25
#define COUNTRYSIZE 26
#define POSTCODESIZE 10
#define TELEPHONESIZE 50
#define FAXSIZE 50
#define EMAILSIZE 50
#define WEBSIZE 100

typedef struct tagRecord {
	//Label info
	char Name[NAMESIZE];
	char Address[ADDRESSSIZE];
	char Address2[ADDRESSSIZE];
	char city[CITYSIZE];
	char country[COUNTRYSIZE];
	char postcode[POSTCODESIZE];

	BOOL omit;
	//Communication info
	char Telephone[TELEPHONESIZE];
	char Telephone2[TELEPHONESIZE];
	char Fax[FAXSIZE];
	char Email[EMAILSIZE];
	char Web[WEBSIZE];

	//Extra info
	
}RECORD, *LPRECORD;

typedef struct tagRecordHeader {
	char id[2];
	int NoRec;
} RECORDHEADER, *LPRECORDHEADER;

RECORD GetRecord (HWND hDlg);
  void SetRecord (HWND hDlg, RECORD rec);
   
  int  OpenRecordFile(char * szFilename, char * access);
  BOOL EnumRecords (LPRECORD rec);
  void CloseRecordFile ();
  
RECORD RereadRecord (char * szFilename, int rec);
BOOL WriteRecord (LPRECORD rec);
BOOL WriteRecordHeader (LPRECORDHEADER rec);
#endif /* FIO_H */