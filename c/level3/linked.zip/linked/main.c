#include <windows.h>
#include "resource.h"
#include <string.h>
#include <commdlg.h>
#include "Clipboard.h"

//My files
#include "DataBase.h"
#include "fio.h"
#include "Printing.h"

BOOL CALLBACK DlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);
void RecordStatus (HWND hDlg, int Total, int Cur );
void OFNSET ();

OPENFILENAME ofn;
HINSTANCE hInst;

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, 
			 LPSTR lpCmdLine, int nCmdShow )
{
	int DlgRet;
	hInst = hInstance;
	DlgRet = DialogBox (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgProc);
	return DlgRet;
}

BOOL CALLBACK DlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	RECORD rec;
	BOOL er;
	char Caption[30];	
	UINT uiCount;
	int TRec, CRec;
	static char szFilter[] = "DGB Files (*.DGB)\0*.dgb\0\0";
	static char szTitle [_MAX_FNAME + _MAX_EXT];
	static char szFilename[_MAX_PATH];
	static BOOL Mod = FALSE;
	static BOOL kMod = FALSE;

	switch(iMsg)
	{
		case WM_INITDIALOG :
				er = CreateBase();
				rec = ReturnBlankRecord();
				AddRecord ( rec );
				SetDlgItemText ( hDlg, IDC_ADDREC, "Save Rec");
				RecordStatus (hDlg, 0, 0);
								
				SetWindowText (hDlg, "Contact Addresses, UNTITLED");
				szTitle[0] = '\0';
				szFilename[0] = '\0';
				break;
	
	case WM_COMMAND :
			
			switch (LOWORD(wParam))
			{
			case IDC_OPENFILE :
					er = DestroyBase();
					er = CreateBase();
					if(er == FALSE) break;
					szFilename[0] = '\0';

					OFNSET();
					
					ofn.lpstrFile = szFilename;				
					ofn.lpstrFileTitle = szTitle ;					
					ofn.lpstrTitle = "Open Database";
					ofn.Flags = OFN_HIDEREADONLY;
					ofn.lpstrFilter = szFilter;
					ofn.hwndOwner = hDlg;

					er = GetOpenFileName (&ofn);
					
					if(er == 0) break;

					er = OpenDataBase ( szFilename );					
					if(er == FALSE) break;
					rec = ReturnRecord ();
					SetRecord(hDlg, rec);
					
					SetDlgItemText ( hDlg, IDC_ADDREC, "Add Rec");
					ReturnDBInfo(&TRec, &CRec);
					RecordStatus(hDlg, TRec, CRec);
					Mod = FALSE;
					
					wsprintf(Caption, "Contact Addresses, %s", szTitle ); 
					SetWindowText (hDlg, Caption );
					break;

			case IDC_SAVEASFILE :
					OFNSET();
					
					ofn.lpstrFile = szFilename;				
					ofn.lpstrFileTitle = szTitle ;					
					ofn.lpstrTitle = "Save Database";
					ofn.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
					ofn.lpstrFilter = szFilter;
					ofn.hwndOwner = hDlg;

					er = GetSaveFileName ( &ofn );

					if(er == 0) break;
					uiCount = GetDlgItemText ( hDlg, IDC_ADDREC, Caption, 8);

					if(strcmp(Caption, "Add Rec") != 0)
					{
						rec = GetRecord ( hDlg );
						SaveRecord ( rec );
						SetDlgItemText ( hDlg, IDC_ADDREC, "Add Rec" );
					}
					
					SaveDataBase ( szFilename );
					Mod = FALSE;
					wsprintf(Caption, "Contact Addresses, %s", szTitle ); 
					SetWindowText (hDlg, Caption );
					
					break;
		
			case IDC_SAVEFILE :
					
				if(szFilename[0] == '\0')
				{
					OFNSET();
					
					ofn.lpstrFile = szFilename;				
					ofn.lpstrFileTitle = szTitle ;					
					ofn.lpstrTitle = "Save Database";
					ofn.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
					ofn.lpstrFilter = szFilter;
					ofn.hwndOwner = hDlg;

					er = GetSaveFileName ( &ofn );

					if(er == 0) break;
					Mod = FALSE;
				}

					uiCount = GetDlgItemText ( hDlg, IDC_ADDREC, Caption, 8);

					if(strcmp(Caption, "Add Rec") != 0)
					{
						rec = GetRecord ( hDlg );
						SaveRecord ( rec );
						SetDlgItemText ( hDlg, IDC_ADDREC, "Add Rec" );
					}
					
					SaveDataBase ( szFilename );
					Mod = FALSE;
					
					wsprintf(Caption, "Contact Addresses, %s", szTitle ); 
					SetWindowText (hDlg, Caption );
					
					break;
			
			case IDC_CLOSEFILE :
					er = DestroyBase();
					er = CreateBase();
					if(er == FALSE) break;

					rec = ReturnBlankRecord();
					AddRecord ( rec );
					SetRecord(hDlg, rec);
					RecordStatus(hDlg, 1, 1);
					szFilename[0] = '\0';
					szTitle[0] = '\0';
					Mod = FALSE;
					SetWindowText (hDlg, "Contact Addresses, UNTITLED");
					break;
			
			case IDC_NEXT :
					kMod = TRUE;
					NextRecord();
					rec = ReturnRecord ();				
					SetRecord(hDlg, rec);
					
				//Update status...
					ReturnDBInfo(&TRec, &CRec);
					RecordStatus(hDlg, TRec, CRec);
									
					break;

			case IDC_PREV :
					kMod = TRUE;	 //The prevents the AddRec button changing to SaveRec
					PrevRecord();
					rec = ReturnRecord ();
					kMod = TRUE;
					SetRecord(hDlg, rec); 
					
					ReturnDBInfo(&TRec, &CRec);
					RecordStatus(hDlg, TRec, CRec);
												                    
					break;

			case IDC_ADDREC :
					//Clear
					uiCount = GetDlgItemText ( hDlg, IDC_ADDREC, Caption, 8);
										
					if(strcmp(Caption, "Add Rec") == 0)
					{
						rec = ReturnBlankRecord ();
						AddRecord ( rec );
						SetRecord ( hDlg, rec );
						SetDlgItemText ( hDlg, IDC_ADDREC, "Save Rec" );
					}
					else
					{
						rec = GetRecord ( hDlg );
						SaveRecord ( rec );
						SetDlgItemText ( hDlg, IDC_ADDREC, "Add Rec" );
					}
					
					ReturnDBInfo(&TRec, &CRec);
					RecordStatus(hDlg, TRec, CRec);
					Mod = TRUE;
					break;

			case IDC_DELREC :
					ReturnDBInfo (&TRec, &CRec);

					if(TRec == 1)
					{
						//er = DestroyBase();
						//er = CreateBase();
						//if(er == FALSE) break;

						//rec = ReturnBlankRecord();
						//AddRecord ( rec );
						//SetRecord(hDlg, rec);
						//RecordStatus(hDlg, 1, 1);
						//szFilename[0] = '\0';
						//szTitle[0] = '\0';
						//Mod = FALSE;
						//SetWindowText (hDlg, "Contact Addresses, UNTITLED");
						PostMessage(hDlg, WM_COMMAND, IDC_CLOSEFILE, 0);
						break;
					}
			
					er = DelRecord ();

					if(er == FALSE)
					{
						wsprintf(Caption, "Error code:%d", GetLastError());
						MessageBox(hDlg, Caption, "Er", MB_OK);
					}
					
					ReturnDBInfo (&TRec, &CRec);
					if(CRec == 0)
						NextRecord();

					rec = ReturnRecord ();
					SetRecord(hDlg, rec);									
					ReturnDBInfo(&TRec, &CRec);
					RecordStatus(hDlg, TRec, CRec);
					break;

			case IDC_GOTO:
					//Lets goto a record number..
					
					ReturnDBInfo(&TRec, &CRec);
					CRec = GetDlgItemInt(hDlg, IDC_ST_GOTO, NULL, TRUE );
					
					if((CRec == 0) || (CRec > TRec))
					{
						wsprintf(Caption, "Value out of Range, 1 to %d", TRec);
						MessageBox (hDlg, Caption, "Error", MB_OK);
						break;
					}

					ReturnToZero();
					CRec--;

					for(TRec = 0; TRec < CRec; TRec++)
					{
						NextRecord();
					}

					rec = ReturnRecord ();
					SetRecord( hDlg, rec );
					
					ReturnDBInfo(&TRec, &CRec);
					RecordStatus(hDlg, TRec, CRec);

					break;

			case IDC_NAME :
			case IDC_ADDRESS1 :
			case IDC_ADDRESS2:
			case IDC_CITY:
			case IDC_POSTCODE:
			case IDC_COUNTRY:
			case IDC_TEL:
			case IDC_TEL2:
			case IDC_FAX:
			case IDC_EMAIL:
			case IDC_WEBSITE:			

					if(HIWORD(wParam) == EN_SETFOCUS) 
					{
						kMod = FALSE;
						break;
					}

					if(kMod == TRUE)
						break;

					if(HIWORD(wParam) == EN_UPDATE)
						break;
										
					SetDlgItemText ( hDlg, IDC_ADDREC, "Save Rec" );
					Mod = TRUE;
					break;
			
			case IDC_CH_COUNTRY:
						
					if(kMod == TRUE)
					{
						kMod = FALSE;
						break;
					}

					SetDlgItemText ( hDlg, IDC_ADDREC, "Save Rec" );
					Mod = TRUE;					
					break;


			case IDC_ABOUT :
					MessageBox ( NULL, "DGB - A Database Application\015" \
									   "by Evan Marchant, (c) 1999\015" \
									   "Email at : evan@achaia.dircon.co.uk\015 " \
									   "Web at : http://www.achaia.dircon.co.uk\015" \
									   "// Any Comments - Please Email \\\\ \015", "About my little proggie", MB_OK | MB_ICONINFORMATION);

				    break;
			case IDC_COPY :
					rec = ReturnRecord();					
					CopyRecordToClipBoard(hInst, hDlg, &rec);
					break;

			case IDC_PRINT :
					//PRint WAHOO
					rec = ReturnRecord();					
					er = Print (hInst, hDlg, &rec, szTitle);
					if(er == TRUE)
					{
						MessageBox (hDlg, "Printed", "Printed", MB_OK);
					}
					else
					{
						wsprintf(Caption, "Error code:%d", GetLastError());
						MessageBox(hDlg, Caption, "Error", MB_OK);
					}
					break;
			case ID_EXIT_TIME :			
					EndDialog(hDlg, 0);
					break;
			}
			break;
	}
	return FALSE;
}

void RecordStatus (HWND hDlg,  int Total, int Cur )
{
	char buffer[5];
	wsprintf(buffer, "%d", Cur );
	SetDlgItemText ( hDlg, IDC_ST_RECNO, buffer);
	wsprintf(buffer, "%d", Total );
	SetDlgItemText ( hDlg, IDC_ST_TREC, buffer);
	return;
}

void OFNSET ()
{
	ofn.lStructSize =  sizeof ( OPENFILENAME );
	ofn.hInstance = NULL;					
	ofn.lpstrCustomFilter = NULL;
	ofn.nMaxCustFilter = 0;
	ofn.nFilterIndex = 0;	
	ofn.nMaxFile = _MAX_PATH;
	ofn.nMaxFileTitle = _MAX_FNAME + _MAX_EXT;
	ofn.lpstrInitialDir = NULL;					
	ofn.nFileOffset = 0;
	ofn.nFileExtension = 0;
	ofn.lpstrDefExt = "dgb";
	ofn.lCustData = 0L;
	ofn.lpfnHook = NULL;
	ofn.lpTemplateName = NULL;
	return;
}
