#include <windows.h>
#include "resource.h"
#include "fio.h"
#include <stdio.h>
#define STRICT

FILE *fp;


int OpenRecordFile(char * szFilename, char * access)
{
	RECORDHEADER rhead;
	
	fp = fopen(szFilename, access);

	if(fp == NULL)
	{
		return -1;
	}

	if(access[0] == 'w')
	{
		return 0;
	}

	fread (&rhead, sizeof( RECORDHEADER ), 1, fp);

	if((rhead.id[0] =='E') && (rhead.id[1] == 'M'))
	{
		return rhead.NoRec;
	}
	
	fclose(fp);
	return -1;
}

void CloseRecordFile ()
{
	fclose(fp);
}

BOOL EnumRecords (LPRECORD rec)
{
	fread (rec, sizeof ( RECORD ), 1, fp);

	if(feof(fp))
	{
		return FALSE;
	}
	else
		return TRUE;
}

BOOL WriteRecordHeader (LPRECORDHEADER rec)
{
	fwrite(rec, sizeof (RECORDHEADER), 1, fp);
	return TRUE;
}

BOOL WriteRecord (LPRECORD rec)
{
	fwrite(rec, sizeof ( RECORD ), 1, fp);
	
	if(feof(fp)) //Needed?
		return TRUE;
	else
		return FALSE;
}

RECORD RereadRecord (char * szFilename, int rec)
{
	long int offset;
	int tot = OpenRecordFile(szFilename, "r");
	RECORD rrec;

	offset = sizeof ( RECORDHEADER ) + (rec * sizeof ( RECORD ));
	fseek(fp, offset, SEEK_SET);
	
	fread(&rrec, sizeof ( RECORD ), 1, fp);
	return rrec;
}
	

RECORD GetRecord (HWND hDlg)
{
	RECORD rec;

	GetDlgItemText(hDlg, IDC_NAME, (LPSTR)&rec.Name, NAMESIZE); 
	GetDlgItemText(hDlg, IDC_ADDRESS1, (LPSTR)&rec.Address, ADDRESSSIZE);
	GetDlgItemText(hDlg, IDC_ADDRESS2, (LPSTR)&rec.Address2, ADDRESSSIZE);
	GetDlgItemText(hDlg, IDC_CITY, (LPSTR)&rec.city, CITYSIZE);
	GetDlgItemText(hDlg, IDC_COUNTRY, (LPSTR)&rec.country, COUNTRYSIZE);
	GetDlgItemText(hDlg, IDC_POSTCODE, (LPSTR)&rec.postcode, POSTCODESIZE);
	
	rec.omit = IsDlgButtonChecked(hDlg, IDC_CH_COUNTRY);
	
	GetDlgItemText(hDlg, IDC_TEL, (LPSTR)&rec.Telephone,  TELEPHONESIZE);
	GetDlgItemText(hDlg, IDC_TEL2,(LPSTR)&rec.Telephone2,  TELEPHONESIZE);
	GetDlgItemText(hDlg, IDC_FAX,(LPSTR)&rec.Fax, FAXSIZE);
	GetDlgItemText(hDlg, IDC_EMAIL, (LPSTR)&rec.Email, EMAILSIZE);
	GetDlgItemText(hDlg, IDC_WEBSITE, (LPSTR)&rec.Web, WEBSIZE);

	return rec;
}

void SetRecord (HWND hDlg, RECORD rec)
{
	

	SetDlgItemText(hDlg, IDC_NAME, (LPSTR)&rec.Name); 
	SetDlgItemText(hDlg, IDC_ADDRESS1, (LPSTR)&rec.Address);
	SetDlgItemText(hDlg, IDC_ADDRESS2, (LPSTR)&rec.Address2);
	SetDlgItemText(hDlg, IDC_CITY, (LPSTR)&rec.city);
	SetDlgItemText(hDlg, IDC_COUNTRY, (LPSTR)&rec.country);
	SetDlgItemText(hDlg, IDC_POSTCODE, (LPSTR)&rec.postcode);
	
	CheckDlgButton (hDlg, IDC_CH_COUNTRY, rec.omit);
	
	SetDlgItemText(hDlg, IDC_TEL, (LPSTR)&rec.Telephone);
	SetDlgItemText(hDlg, IDC_TEL2,(LPSTR)&rec.Telephone2);
	SetDlgItemText(hDlg, IDC_FAX,(LPSTR)&rec.Fax);
	SetDlgItemText(hDlg, IDC_EMAIL, (LPSTR)&rec.Email);
	SetDlgItemText(hDlg, IDC_WEBSITE, (LPSTR)&rec.Web);

	return;
}
