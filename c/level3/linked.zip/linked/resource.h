//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DGB.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON1                       107
#define IDD_OPTIONDIALOG                108
#define IDC_NAME                        1000
#define IDC_ADDRESS1                    1001
#define IDC_ADDRESS2                    1002
#define IDC_CITY                        1003
#define IDC_POSTCODE                    1004
#define IDC_COUNTRY                     1005
#define IDC_CH_COUNTRY                  1006
#define IDC_TEL                         1007
#define IDC_TEL2                        1008
#define IDC_FAX                         1009
#define IDC_EMAIL                       1010
#define IDC_WEBSITE                     1011
#define IDC_COMMENTS                    1012
#define IDC_PREV                        1013
#define IDC_NEXT                        1014
#define IDC_ST_GOTO                     1015
#define IDC_GOTO                        1016
#define IDC_ADDREC                      1017
#define IDC_DELREC                      1018
#define IDC_OPENFILE                    1019
#define IDC_SAVEFILE                    1020
#define IDC_CLOSEFILE                   1021
#define IDC_SAVEASFILE                  1022
#define IDC_PRINT                       1023
#define IDC_COPY                        1024
#define IDC_ABOUT                       1025
#define IDC_ST_RECNO                    1026
#define IDC_ST_TREC                     1027
#define ID_EXIT_TIME                    1028
#define IDC_NSEARCH                     1029
#define IDC_SOPTIONS                    1030
#define IDC_SEARCH                      1031
#define IDC_NRES                        1032
#define IDC_PRES                        1033
#define IDC_CH_NAME                     1034
#define IDC_CH_ADDRESS                  1035
#define IDC_CH_ADDRESS2                 1036
#define IDC_CH_CITY                     1037
#define IDC_CH_POSTCODE                 1039
#define IDC_CH_TELEPHONE                1040
#define IDC_CH_TELEPHONE2               1041
#define IDC_CH_FAX                      1042
#define IDC_CH_EMAIL                    1043
#define IDC_CH_WEB                      1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
