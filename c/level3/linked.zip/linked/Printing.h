#ifndef PRINTING_H
#define PRINTING_H

#include <windows.h>
#include <commdlg.h>
#include "fio.h"
#include "DataBase.h"
#include "resource.h"

HDC GetPrinterDC (void);
BOOL PrintRec ( LPRECORD rec );
BOOL PrintRange (int * MyArg);
BOOL CALLBACK PrintDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);
BOOL Print (HINSTANCE hInst, HWND hwnd, LPRECORD rec , char * fname);
#endif //PRINTING_H