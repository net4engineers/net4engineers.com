//Function for copying the damned thing to the
//Clipboard...

//EM

#include "Clipboard.h"

#include "resource.h"
#include <string.h>
	
BOOL bName = TRUE;
BOOL bAddress = TRUE;
BOOL bAddress2 = TRUE;
BOOL bCity = TRUE;
BOOL bCountry = FALSE;
BOOL bPostcode = TRUE;
BOOL bTelephone = FALSE;
BOOL bTelephone2 = FALSE;
BOOL bFax = FALSE;
BOOL bEmail = FALSE;
BOOL bWeb = FALSE;
BOOL bCanceled = FALSE;

void CopyB (char * dest, char * source, int dStart);

void CopyB (char * dest, char * source, int dStart)
{
	int ctr;

	for(ctr = dStart; ; ctr++)
	{
		dest[ctr] = source[(ctr - dStart)];
		if(source[(ctr - dStart) + 1] == '\0')
			break;		
	}
	return;
}

void CopyRecordToClipBoard(HINSTANCE hInst, HWND hwnd, LPRECORD rec)
{
	int iLength = 0;

	char *pszb;
	int count = 0;
	int lLength = 0;
	HANDLE hGlobalMemory;
	char * pGlobalMemory;	
	
	DialogBox (hInst, MAKEINTRESOURCE(IDD_OPTIONDIALOG), hwnd, CopyDlgProc);

	      if(bName) iLength += strlen (rec->Name) + 2;
	   if(bAddress) iLength += strlen(rec->Address) + 2;
	  if(bAddress2) iLength += strlen(rec->Address2) + 2;
	      if(bCity) iLength += strlen(rec->city) + 2;
	   if(bCountry) iLength += strlen(rec->country) + 2;
	  if(bPostcode) iLength += strlen(rec->postcode) + 2;
	 if(bTelephone) iLength += strlen(rec->Telephone) + 2;
	if(bTelephone2) iLength += strlen(rec->Telephone2) + 2;
	       if(bFax) iLength += strlen(rec->Fax) + 2;
	     if(bEmail) iLength += strlen(rec->Email) + 2;
	       if(bWeb) iLength += strlen(rec->Web) + 2;

	hGlobalMemory = GlobalAlloc (GHND, iLength + 23);
	pGlobalMemory = GlobalLock(hGlobalMemory);
	
	if(bName)
	{ 
		lLength = strlen(rec->Name);
		pszb = rec->Name;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}

	if(bAddress)
	{ 		
		lLength = strlen(rec->Address);
		pszb = rec->Address;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}

	if(bAddress2)
	{ 
		lLength = strlen(rec->Address2);
		pszb = rec->Address2;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}

	if(bCity)
	{
		lLength = strlen(rec->city);
		pszb = rec->city;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	      
    if(bCountry) 
	{ 
		lLength = strlen(rec->country);
		pszb = rec->country;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	
	if(bPostcode) 
	{ 
		lLength = strlen(rec->postcode);
		pszb = rec->postcode;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	
	if(bTelephone) 
	{	
		lLength = strlen(rec->Telephone);
		pszb = rec->Telephone;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	
	if(bTelephone2) 
	{ 
		lLength = strlen(rec->Telephone2);
		pszb = rec->Telephone2;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	
	if(bFax) 
	{
		lLength = strlen(rec->Fax);
		pszb = rec->Fax;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	
	if(bEmail) 
	{ 
		lLength = strlen(rec->Email);
		pszb = rec->Email;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	
	if(bWeb) 
	{ 
		lLength = strlen(rec->Web);
		pszb = rec->Web;
		for(count = 0; count < lLength; count++)
		{
			*pGlobalMemory++ = *pszb++;
		}
		*pGlobalMemory++ = '\r';
		*pGlobalMemory++ = '\n';
	}
	
	GlobalUnlock (hGlobalMemory);
	
	
	
	OpenClipboard (hwnd) ;
	EmptyClipboard ();

	SetClipboardData (CF_TEXT, hGlobalMemory) ;
	
	CloseClipboard();
	return;
}

/*void CRecClipboard(HWND hwnd, char * szb, int iLength)
{	
	HANDLE hGlobalMemory;
	char * pGlobalMemory;	
	int ctr;

	//iLength = strlen(rec->Name) + strlen(rec->Address) + strlen(rec->Address2) + 
	//	strlen(rec->city) + strlen(rec->country) + strlen(rec->postcode) + 
	//	strlen(rec->Telephone) + strlen(rec->Telephone2) + strlen(rec->Fax) + 
	//	strlen(rec->Email) + strlen(rec->Web);
	// szb = HeapAlloc( GetProcessHeap(), 0, 22 + (iLength * sizeof ( char )));

	//wsprintf(szb, "%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n",
	//	rec->Name, rec->Address, rec->Address2, rec->city, rec->country,
	//	rec->postcode, rec->Telephone, rec->Telephone2, rec->Fax,
	//	rec->Email, rec->Web);
	
	hGlobalMemory = GlobalAlloc (GHND, iLength + 23);
	pGlobalMemory = GlobalLock(hGlobalMemory);

	for(ctr = 0; ctr < (iLength); ctr++)
	{
		*pGlobalMemory++ = *szb++;
	}
	 
	GlobalUnlock (hGlobalMemory);

	//HeapFree (GetProcessHeap(), 0, szb);
	OpenClipboard (hwnd) ;
	EmptyClipboard ();

	SetClipboardData (CF_TEXT, hGlobalMemory) ;
	
	CloseClipboard();
	return;
}*/

BOOL CALLBACK CopyDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch (iMsg)
	{
		case WM_INITDIALOG :
			if(bName) CheckDlgButton(hDlg, IDC_CH_NAME, 1);
			if(bAddress) CheckDlgButton(hDlg, IDC_CH_ADDRESS, 1);
			if(bAddress2) CheckDlgButton(hDlg, IDC_CH_ADDRESS2, 1);
			if(bCity) CheckDlgButton(hDlg, IDC_CH_CITY, 1);
			if(bCountry) CheckDlgButton(hDlg, IDC_CH_COUNTRY, 1);
			if(bPostcode) CheckDlgButton(hDlg, IDC_CH_POSTCODE, 1);
			if(bTelephone) CheckDlgButton(hDlg, IDC_CH_TELEPHONE, 1);
			if(bTelephone2) CheckDlgButton(hDlg, IDC_CH_TELEPHONE2, 1);
			if(bFax) CheckDlgButton(hDlg, IDC_CH_FAX, 1);
			if(bEmail) CheckDlgButton(hDlg, IDC_CH_EMAIL, 1);
			if(bWeb) CheckDlgButton(hDlg, IDC_CH_WEB, 1);
			SetWindowText (hDlg, "Copy Options");
			break;
		case WM_COMMAND :
			switch(LOWORD(wParam))
			{
				case IDCANCEL :
					bCanceled = TRUE;
					EndDialog (hDlg, 1);
					break;
				case IDOK :
			if(IsDlgButtonChecked(hDlg, IDC_CH_NAME) == BST_CHECKED) 
				bName = TRUE;
			else
				bName = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_ADDRESS) == BST_CHECKED)
				bAddress = TRUE;
			else
				bAddress = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_ADDRESS2) == BST_CHECKED) 
				bAddress2 = TRUE;
			else
				bAddress2 = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_CITY) == BST_CHECKED) 
				bCity = TRUE;
			else
				bCity = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_COUNTRY) == BST_CHECKED) 
				bCountry = TRUE;
			else
				bCountry = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_POSTCODE) == BST_CHECKED) 
				bPostcode = TRUE;
			else
				bPostcode = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_TELEPHONE) == BST_CHECKED)			
				bTelephone = TRUE;
			else
				bTelephone = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_TELEPHONE2) == BST_CHECKED)
				bTelephone2 = TRUE;
			else
				bTelephone2 = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_FAX) == BST_CHECKED)
				bFax = TRUE;
			else
				bFax = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_EMAIL) == BST_CHECKED)
				bEmail = TRUE;
			else
				bEmail = FALSE;

			if(IsDlgButtonChecked(hDlg, IDC_CH_WEB) == BST_CHECKED)
				bWeb = TRUE;
			else
				bWeb = FALSE;
					
			EndDialog (hDlg, 1);
		
			break;
			}
		}
	return FALSE;
}