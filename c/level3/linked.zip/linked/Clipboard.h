#ifndef CLIPBORD_H
#define CLIPBORD_H

#include "fio.h"
#include <windows.h>

void CopyRecordToClipBoard(HINSTANCE hInst, HWND hwnd, LPRECORD rec);
//void CRecClipboard(HWND hwnd, char * szb, int iLength);

BOOL CALLBACK CopyDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);
#endif /* CLIPBORD_H */