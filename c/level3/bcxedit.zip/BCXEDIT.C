//***************************************************************
//   Created with BCX -- The BASIC To C Translator (ver 2.07)
//        BCX (c) 1999, 2000, 2001 by Kevin Diggins
//**************************************************************
 
#include <windows.h>     // Windows Specific Header File 
#include <windowsx.h>    // Windows Specific Header File 
#include <commctrl.h>    // Windows Specific Header File 
#include <mmsystem.h>    // Windows Specific Header File 
#include <shellapi.h>    // Windows Specific Header File 
#include <shlobj.h>      // Windows Specific Header File 
#include <winsock.h>     // Windows Specific Header File 
#include <conio.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include <setjmp.h>
#include <time.h>

//****************************
//     System Variables
//****************************

int   StrCnt;
LPSTR StrFunc [16];

//****************************
//   User Defined Constants
//****************************

#define EDIT_1 111
#define IDM_NEW 100
#define IDM_OPEN 110
#define IDM_SAVE 120
#define IDM_SAVEAS 130
#define IDM_PRINT 140
#define IDM_PAGESETUP 150
#define IDM_EXIT 160
#define IDM_UNDO 200
#define IDM_SELECTALL 205
#define IDM_CUT 210
#define IDM_COPY 220
#define IDM_PASTE 230
#define IDM_HELPTOPICS 300
#define IDM_ABOUT 310
#define IDACCEL 400
#define IDM_DELETE 410
#define IDM_CLOSE 420
#define IDMAINMENU 430
#define IDAPPLICON 440
#define IDAPPLCURSOR 450
#define IDS_FILEMENU 2000
#define IDS_HELPMENU 2010
#define IDS_SYSMENU 2030
#define IDM_STATUSBAR 3000
#define IDD_ABOUT 460
#define ID_TOOLBAR 805
#define IDC_EDIT 900

//****************************
//   User Global Variables
//****************************

static  char   AppName [2048];
static  char   Caption [2048];
static  char   AppMenu [2048];
static  char   szFile [2048];
static  char   szFileTitle [2048];
static  HWND  Form1;
static  HWND  Edit1;
static  MSG  Msg;
static  WNDCLASS  Wc;
static  HWND  hInst;
static  OPENFILENAME  OpenFileName;
static  RECT  wRect;
static  DWORD  ww;
static  DWORD  wh;
static  BOOL  bNeedSave;
static  BOOL  bSave;
static  DWORD  iReturn;
static  LPSTR  File;
FILE *  Fp1;

//****************************
//   Standard Prototypes
//****************************

extern int exist (char *);
extern char * curdir (void);
extern char *str (double);
extern char *chr (char);
extern int eof (FILE *);
extern int MsgBox (char *, char *, int);

//****************************
//     User's Prototypes
//****************************

extern int WinMain (HWND, HWND, LPSTR, int );
extern int InitOpenFileName (void);
extern int PopFileOpenDlg (HWND, char *, char *);
extern void OpenNewFile (HWND);
extern int PopFileSaveDlg (HWND, char *, char *);
extern void SaveOpenFile (HWND);
extern int AboutDlg (HWND, int , int , int );
extern LRESULT CALLBACK WndProc (HWND, UINT, UINT, int );
extern void CenterWindow (HWND);
extern void PosMainWindow (HWND);
extern int AskAboutSave (HWND, char *);
extern void notice (char *);
extern int FindFirstInstance (char *);

// control constants
// menu constants
// Edit Menu
// Help Menu
// Window Controls
// program variables

//****************************
//    Run Time Functions
//****************************


extern int MsgBox (char *Msg, char *Title, int Num)
{
return MessageBox(NULL,Msg,Title,Num);
}




extern char *str (double d)
{
//**************************************************
if (++StrCnt==16) StrCnt = 0;
if (StrFunc[StrCnt]) free (StrFunc[StrCnt]);
StrFunc[StrCnt] = (char*) malloc (2048);
memset (StrFunc[StrCnt],0,2048);
//**************************************************
sprintf(StrFunc[StrCnt],"% .16g",d);
return StrFunc[StrCnt];
}




extern char *curdir (void)
{
//**************************************************
if (++StrCnt==16) StrCnt = 0;
if (StrFunc[StrCnt]) free (StrFunc[StrCnt]);
StrFunc[StrCnt] = (char*) malloc (2048);
memset (StrFunc[StrCnt],0,2048);
//**************************************************
GetCurrentDirectory (1024,StrFunc[StrCnt]);
return StrFunc[StrCnt];
}




extern char *chr (char d)
{
//**************************************************
if (++StrCnt==16) StrCnt = 0;
if (StrFunc[StrCnt]) free (StrFunc[StrCnt]);
StrFunc[StrCnt] = (char*) malloc(256);
//**************************************************
StrFunc[StrCnt][0] = d;
StrFunc[StrCnt][1] = 0;
return StrFunc[StrCnt];
}




extern int exist (char *FileName)
{
WIN32_FIND_DATA FindData;
HANDLE rc;
rc=FindFirstFile(FileName,&FindData);
if(rc==INVALID_HANDLE_VALUE)
 return  0;
else
 return -1;
}




extern int eof (FILE *stream)
{
int c, status;
status=((c=fgetc(stream))==EOF);
ungetc(c,stream);
return status;
}



//*********************************************************
//                 User Subs and Functions
//*********************************************************


extern int WinMain (HWND hInst, HWND hPrev, LPSTR CmdParam, int CmdShow)
{
sprintf(AppName,"%s","Editor_Demo");
sprintf(AppMenu,"%s","IDMAINMENU");
sprintf(Caption,"%s","Editor by Doyle Whisenant");
bSave=TRUE;
bNeedSave=FALSE;
if(FindFirstInstance(AppName))
  {
  return 0;
  }
Wc.style=CS_HREDRAW|CS_VREDRAW;
Wc.lpfnWndProc=WndProc;
Wc.cbClsExtra=0;
Wc.cbWndExtra=0;
Wc.hInstance=hInst;
Wc.hIcon=LoadIcon(NULL,IDI_APPLICATION);
Wc.hCursor=LoadCursor(NULL,IDC_ARROW);
Wc.hbrBackground=GetStockObject(WHITE_BRUSH);
Wc.lpszMenuName=AppMenu;
Wc.lpszClassName=AppName;
RegisterClass(&Wc);
// create the main window
Form1=CreateWindow(AppName,Caption,WS_CAPTION|WS_MAXIMIZEBOX|WS_MINIMIZEBOX|WS_SYSMENU|WS_VISIBLE,0,0,600,500,NULL,(HMENU)NULL,hInst,NULL);
// create the edit window
Edit1=CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|WS_BORDER|ES_LEFT|WS_HSCROLL|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL,0,0,550,450,Form1,(HMENU)EDIT_1,hInst,NULL);
PosMainWindow(Form1);
ShowWindow(Form1,CmdShow);
UpdateWindow(Form1);
while(GetMessage(&Msg,NULL,0,0))
  {
  TranslateMessage(&Msg);
  DispatchMessage(&Msg);
  }
return Msg.wParam;
}


extern int InitOpenFileName (void)
{
sprintf(szFile,"%s","");
sprintf(szFileTitle,"%s","");
OpenFileName.lStructSize=sizeof(OPENFILENAME);
OpenFileName.hwndOwner=Form1;
OpenFileName.hInstance=hInst;
// --------------------------------------------------------------------
OpenFileName.lpstrFilter =
"Basic Files (*.BAS)\0*.bas\0All Files(*.*)\0*.*\0\0";
// --------------------------------------------------------------------
OpenFileName.lpstrCustomFilter=NULL;
OpenFileName.nMaxCustFilter=0;
OpenFileName.nFilterIndex=0;
OpenFileName.lpstrFile=szFile;
OpenFileName.nMaxFile=MAX_PATH;
OpenFileName.lpstrFileTitle=szFileTitle;
OpenFileName.nMaxFileTitle=MAX_PATH;
OpenFileName.lpstrInitialDir=curdir();
OpenFileName.lpstrTitle=NULL;
OpenFileName.nFileOffset=0;
OpenFileName.nFileExtension=0;
OpenFileName.lpstrDefExt="*.txt";
OpenFileName.lCustData=0L;
OpenFileName.Flags=OFN_SHOWHELP|OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST|OFN_HIDEREADONLY;
OpenFileName.lpfnHook=NULL;
OpenFileName.lpTemplateName=NULL;
return 0;
}


extern int PopFileOpenDlg (HWND Form1, char *szFile, char *szFileTitle)
{
OpenFileName.lpstrTitle="Open File";
OpenFileName.hwndOwner=Form1;
OpenFileName.lpstrFile=szFile;
OpenFileName.lpstrFileTitle=szFileTitle;
OpenFileName.Flags=OFN_HIDEREADONLY|OFN_CREATEPROMPT;
return GetOpenFileName(&OpenFileName);
}


extern void OpenNewFile (HWND hWnd)
{
static  DWORD  t;
memset(&t,0,sizeof(t));
static char FileBuf[2048];
memset(&FileBuf,0,sizeof(FileBuf));
File=(char*)malloc(256+65535);
File[0]=0;
sprintf(File,"%s","");
t=exist(szFile);
if((t!=0))
  {
  if((Fp1= fopen(szFile,"r")) == NULL)
   {
    fprintf(stderr,"Can't open file");exit(1);
   }
  while(!eof(Fp1))
    {
    fgets(FileBuf,1024,Fp1);
    FileBuf[strlen(FileBuf) - 1] = 0;
    sprintf(File,"%s%s%s%s",File,FileBuf,chr(13),chr(10));
    }
  fclose(Fp1);
  SendMessage(Edit1,(UINT)WM_SETTEXT,(WPARAM)0,(LPARAM)File);
  free(File  );
  }
else
  {
  MessageBox(Edit1,"File open failed.",NULL,MB_OK);
  }
}


extern int PopFileSaveDlg (HWND Form1, char *szFile, char *szFileTitle)
{
OpenFileName.lpstrTitle="Save File";
OpenFileName.hwndOwner=Form1;
OpenFileName.lpstrFile=szFile;
OpenFileName.lpstrFileTitle=szFileTitle;
OpenFileName.Flags=OFN_OVERWRITEPROMPT;
return GetSaveFileName(&OpenFileName);
}


extern void SaveOpenFile (HWND hWnd)
{
static  DWORD  t;
memset(&t,0,sizeof(t));
static  DWORD  iLength;
memset(&iLength,0,sizeof(iLength));
iLength=GetWindowTextLength(Edit1);
File=(char*)malloc(256+iLength+1);
File[0]=0;
sprintf(File,"%s","");
t=GetWindowText(Edit1,File,iLength);
if(exist(File))
  {
  if((Fp1= fopen(szFile,"w")) == NULL)
   {
    fprintf(stderr,"Can't open file");exit(1);
   }
fprintf(Fp1,"%s\n",File);
  fclose(Fp1);
  free(File  );
  }
else
  {
  MessageBox(Edit1,"File Save failed.",NULL,MB_OK);
  }
}


extern int AboutDlg (HWND hDlg, int Msg, int wParam, int lParam)
{
for(;;)
{
if(Msg==WM_INITDIALOG)
  {
  CenterWindow(hDlg);
  break;
  }
if(Msg==WM_COMMAND)
  {
  if(wParam==IDOK)
    {
    EndDialog(hDlg,0);
    }
  break;
  }
if(Msg==WM_CLOSE)
  {
  EndDialog(hDlg,0);
  }
  break;
}
return 0;
}


extern LRESULT CALLBACK WndProc (HWND hwnd, UINT Msg, UINT wParam, int lParam)
{
static char T[2048];
memset(&T,0,sizeof(T));
static  HDC  hDC;
memset(&hDC,0,sizeof(hDC));
static  PAINTSTRUCT  ps;
memset(&ps,0,sizeof(ps));
static int i;
memset(&i,0,sizeof(i));
for(;;)
{
if(Msg==WM_COMMAND)
  {
  if(LOWORD(wParam)==EDIT_1)
    {
    if(HIWORD(wParam)==EN_CHANGE)
      {
      bNeedSave=TRUE;
      if(HIWORD(wParam)==EN_ERRSPACE||HIWORD(wParam)==EN_MAXTEXT)
        {
        MessageBox (NULL,"Edit control out of space.","Error!",16);
        return         0;
        }
      }
    return     0;
    }
  if(LOWORD(wParam)==IDM_NEW)
    {
    SendMessage(Edit1,(UINT)EM_SETSEL,(WPARAM)0,(LPARAM)MAKELONG(-1,0));
    SendMessage(Edit1,(UINT)WM_CLEAR,(WPARAM)0,(LPARAM)0);
    sprintf(szFile,"%s","");
    sprintf(szFileTitle,"%s","");
    sprintf(Caption,"%s","Editor by Doyle Whisenant");
    SetWindowText(Form1,Caption);
    bNeedSave=FALSE;
    return     0;
    }
  if(LOWORD(wParam)==IDM_OPEN)
    {
    if(bNeedSave)
      {
      i=(AskAboutSave(Edit1,szFileTitle));
      }
    if(i==IDCANCEL)
      {
      return       0;
      }
    if(i==IDNO)
      {
      bNeedSave=FALSE;
      }
    if(i==IDYES)
      {
      InitOpenFileName();
      PopFileSaveDlg(Form1,szFile,szFileTitle);
      SaveOpenFile(Edit1);
      bNeedSave=FALSE;
      }
    if(!bNeedSave)
      {
      sprintf(Caption,"%s","Editor by Doyle Whisenant");
      SetWindowText(Form1,Caption);
      InitOpenFileName();
      PopFileOpenDlg(Form1,szFile,szFileTitle);
      OpenNewFile(Edit1);
      sprintf(Caption,"%s%s%s",Caption," - ",szFile);
      SetWindowText(Form1,Caption);
      bNeedSave=FALSE;
      }
    }
  if(LOWORD(wParam)==IDM_PRINT)
    {
    MessageBox (NULL,"Sorry - Not implemented yet!","Notice",64);
    }
  if(LOWORD(wParam)==IDM_SAVE)
    {
    sprintf(Caption,"%s","BCX Editor by MeKanixx Designs");
    SetWindowText(Form1,Caption);
    SaveOpenFile(Edit1);
    sprintf(Caption,"%s%s%s",Caption," - ",szFile);
    SetWindowText(Form1,Caption);
    bNeedSave=FALSE;
    return     0;
    }
  if(LOWORD(wParam)==IDM_SAVEAS)
    {
    if(bNeedSave)
      {
      i=(AskAboutSave(Edit1,szFileTitle));
      if(i==IDCANCEL)
        {
        return         0;
        }
      if(i==IDNO)
        {
        bSave=FALSE;
        }
      if(i==IDYES)
        {
        bSave=TRUE;
        }
      }
    if(bSave)
      {
      sprintf(szFile,"%s","");
      sprintf(szFileTitle,"%s","");
      InitOpenFileName();
      PopFileSaveDlg(Form1,szFile,szFileTitle);
      SaveOpenFile(Edit1);
      sprintf(Caption,"%s%s%s",Caption," - ",szFile);
      SetWindowText(Form1,Caption);
      bNeedSave=FALSE;
// Function = 0
      }
    }
  if(LOWORD(wParam)==IDM_PRINT)
    {
    notice("Sorry - Not implemented yet!");
    }
  if(LOWORD(wParam)==IDM_DELETE)
    {
    SendMessage(Edit1,(UINT)WM_CLEAR,(WPARAM)0,(LPARAM)0);
    sprintf(Caption,"%s%s%s",Caption," - ",szFile);
    SetWindowText(Form1,Caption);
    bNeedSave=TRUE;
    }
  if(LOWORD(wParam)==IDM_UNDO)
    {
    if(SendMessage(Edit1,EM_CANUNDO,0,0))
      {
      SendMessage(Edit1,(UINT)WM_UNDO,(WPARAM)0,(LPARAM)0);
      }
    else
      {
      MessageBox (NULL,"Nothing to undo!","Undo Notification",0);
      }
    }
  if(LOWORD(wParam)==IDM_CUT)
    {
    SendMessage(Edit1,(UINT)WM_CUT,(WPARAM)0,(LPARAM)0);
    }
  if(LOWORD(wParam)==IDM_COPY)
    {
    SendMessage(Edit1,(UINT)WM_COPY,(WPARAM)0,(LPARAM)0);
    }
  if(LOWORD(wParam)==IDM_PASTE)
    {
    SendMessage(Edit1,(UINT)WM_PASTE,(WPARAM)0,(LPARAM)0);
    }
  if(LOWORD(wParam)==IDM_SELECTALL)
    {
    SendMessage(Edit1,(UINT)EM_SETSEL,(WPARAM)0,(LPARAM)MAKELONG(-1,0));
    }
  if(LOWORD(wParam)==IDM_EXIT)
    {
    if(bNeedSave==TRUE)
      {
      MessageBox (NULL,"File has changed. Save?","Confirm",35);
      if(IDYES)
        {
        InitOpenFileName();
        PopFileSaveDlg(Form1,szFile,szFileTitle);
        SaveOpenFile(Edit1);
        }
      }
    PostQuitMessage(0);
    }
  if(LOWORD(wParam)==IDM_ABOUT)
    {
    MessageBeep(MB_OK);
    DialogBox(hInst,MAKEINTRESOURCE(IDD_ABOUT),Form1,AboutDlg);
    }
  return   0;
  break;
  }
if(Msg==WM_SETFOCUS)
  {
  SetFocus(Edit1);
  return   0;
  break;
  }
if(Msg==WM_PAINT)
  {
  hDC=BeginPaint(hwnd,&ps);
  sprintf(T,"%s%s%s","Editbox is using",str(GetWindowTextLength(Edit1))," bytes");
  TextOut(hDC,75,128,T,strlen(T));
  EndPaint(hwnd,&ps);
  return   0;
  break;
  }
if(Msg==WM_SIZE)
  {
  MoveWindow(Edit1,0,0,LOWORD(lParam),HIWORD(lParam),TRUE);
  return   0;
  break;
  }
if(Msg==WM_KEYDOWN)
  {
  if(wParam==VK_DELETE)
    {
    SendMessage(Edit1,(UINT)WM_CLEAR,(WPARAM)0,(LPARAM)0);
    sprintf(Caption,"%s%s%s",Caption," - ",szFile);
    SetWindowText(Form1,Caption);
    bNeedSave=TRUE;
    }
  return   0;
  break;
  }
if(Msg==WM_DESTROY)
  {
  PostQuitMessage(0);
  return   0;
  break;
  }
if(Msg==WM_LBUTTONDOWN)
  {
  notice("Made it!");
  return   0;
  }
  break;
}
return DefWindowProc(hwnd,Msg,wParam,lParam);
}


extern void CenterWindow (HWND hWnd)
{
static  RECT  wRect;
memset(&wRect,0,sizeof(wRect));
static  DWORD  x;
memset(&x,0,sizeof(x));
static  DWORD  y;
memset(&y,0,sizeof(y));
GetWindowRect(hWnd,&wRect);
x=(GetSystemMetrics(SM_CXSCREEN)-(wRect.right-wRect.left))/2;
y=(GetSystemMetrics(SM_CYSCREEN)-(wRect.bottom-wRect.top+GetSystemMetrics(SM_CYCAPTION)))/2;
SetWindowPos(hWnd,NULL,x,y,0,0,SWP_NOSIZE|SWP_NOZORDER);
}


extern void PosMainWindow (HWND hWnd)
{
GetWindowRect(hWnd,&wRect);
ww=GetSystemMetrics(SM_CXSCREEN);
wh=GetSystemMetrics(SM_CYSCREEN)-GetSystemMetrics(SM_CYCAPTION)-5;
SetWindowPos(hWnd,NULL,0,0,ww,wh,SWP_SHOWWINDOW);
}


extern int AskAboutSave (HWND hWnd, char *szFileTitle)
{
static char afile[2048];
memset(&afile,0,sizeof(afile));
sprintf(afile,"%s%s",szFileTitle," has changed. Save it?");
iReturn=MsgBox(afile,"Confirm",35);
return iReturn;
}


extern void notice (char *a)
{
MessageBox (NULL,a,"Notice",64);
}


extern int FindFirstInstance (char *ApplName)
{
static  HWND  hWnd;
memset(&hWnd,0,sizeof(hWnd));
hWnd=FindWindow(ApplName,NULL);
if(hWnd)
  {
  return   TRUE;
  }
return FALSE;
}
