// _Menu.cpp: implementation of the _Menu class.
//
//////////////////////////////////////////////////////////////////////

#ifndef ESC
	#define ESC       0x1b
#endif
#ifndef UP
	#define UP        72
#endif
#ifndef DOWN
	#define DOWN      80
#endif
#ifndef LEFT
	#define LEFT      75
#endif
#ifndef RIGHT
	#define RIGHT     77
#endif

#include "_Menu.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*=========================== Menu =================================*/
_Menu::_Menu()
{
	_MenuLen = 0;
	Head = Current = Tail = NULL;
	_Name = NULL;
	_ID = Len = _X = _Y = _HColor = _FColor = _BColor
		= _HighLight = _SFColor = _SBColor = 0;
	_SKey = '\0';
	_TotalMenus = 0;
	_NextPos = 0;
}

_Menu::~_Menu()
{
	Current = Head;
	while (Current != NULL)
	{
		Current = Current->Next;
		delete Head;
		Head = Current;
	}
	Head = Current = Tail = NULL;	
	if (_Name != NULL)
		delete [] _Name;
	Head = Current = Tail = NULL;
}	

void _Menu::SetXY(int X, int Y)
{
	_X = X;
	_Y = Y;
}
/*
void _Menu::SortMenus()
{
	_MenuItem *Left, *Right, *Temp;
	Left = Right = Head;
	while (Left != NULL)
	{
		while (Right != NULL)
		{
			if (Right->ID() < Left->ID())
			{
				Temp = new _MenuHeader;
				Temp->Next = Left->Next;
				Temp->Previous = Left->Previous;
				Temp->SetID(Left->ID());

				Left->Next = Right->Next;
				Left->Previous = Right->Previous;
				Left->SetID(Right->ID());

				Right->Next = Temp->Next;
				Right->Previous = Temp->Previous;
				Right->SetID(Temp->ID());
				delete Temp;
			}
			Right = Right->Next;
		}
		Left = Left->Next;
		Right = Left;
	}
}
*/
int _Menu::TotalMenus() const
{
	return _TotalMenus;
}

int _Menu::ID() const
{
	return _ID;
}

char* _Menu::Name() const
{
	return _Name;
}

int _Menu::SFColor() const
{
	return _SFColor;
}

int _Menu::Run()
{
	int Input;
	bool _Exit = false;
	Current = Head;
	while (1)
	{
		switch(Current->Run())
		{
		case ESC:
			_Exit = true;
			break;
		case 0:
			_Exit = true;
			break;
		case -1:
			if (Current == Head)
				Current = Tail;
			else
				Current = Current->Previous;
			break;
		case 1:
			if (Current == Tail)
				Current = Head;
			else
				Current = Current->Next;
			break;
		}
		if (_Exit)
			break;
	}
	return Input;
}

int _Menu::SBColor() const
{
	return _SBColor;
}

void _Menu::SetID(int ID)
{
	_ID = ID;
}

void _Menu::SetName(char *Name)
{
	Len = 0;
	while (Name[Len] != '\0')
		Len++;
	if (_Name != NULL)
		delete [] _Name;
	_Name = new char[Len + 1];
	int i;
	for (i = 0; i < Len; i++)
	{
		if (_Name[i] == '&')
		{
			_SKey = _Name[++i];
			i--;
		}
		_Name[i] = Name[i];
	}
	_TotalMenus++;
}

void _Menu::SetSBColor(int Color)
{
	_SBColor = Color;
}

void _Menu::SetSFColor(int Color)
{
	_SFColor = Color;
}

int _Menu::X() const
{
	return _X;
}

int _Menu::Y() const
{
	return _Y;
}

int _Menu::HColor() const
{
	return _HColor;
}

void _Menu::Draw()
{
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X, _Y);
	Current = Head;
	while (Current != NULL)
	{
		Current->Draw();
		Current = Current->Next;
	}
}

int _Menu::FColor() const
{
	return _FColor;
}

void _Menu::AddItem(int ID, char *Name)
{
	Current = new _MenuHeader;
	if (Head == NULL)
	{
		Head = Tail = Current;
		Head->Previous = NULL;
		Tail->Next = NULL;
	}
	else
	{
		Tail->Next = Current;
		Current->Previous = Tail;
		Tail = Current;
		Tail->Next = NULL;
	}
	Current->SetName(Name);
	Current->SetBColor(_BColor);
	Current->SetFColor(_FColor);
	Current->SetHColor(_HColor);
	Current->SetID(ID);
	Current->SetSBColor(_SBColor);
	Current->SetSFColor(_SFColor);
	_TotalMenus++;
	if (Current == Head)
		Current->SetXY(_X + 2, _Y);
	else
		Current->SetXY(_X + 2 + _NextPos, _Y);
	_NextPos += Current->Len() + 1;
//	SortItems();
}

void _Menu::AddSubMenuBar(int MenuID)
{
	while (Current->ID() != MenuID)
		Current = Current->Next;
	Current->AddBar();
}	

void _Menu::AddSubMenuItem(int MenuID, int SubMenuID, char *Name, void (*Function)())
{
	Current = Head;
	while (Current->ID() != MenuID)
		Current = Current->Next;
	Current->AddItem(SubMenuID, Name, Function);
	
}

int _Menu::BColor() const
{
	return _BColor;
}

void _Menu::SetHColor(int Color)
{
	_HColor = Color;
}

void _Menu::SetBColor(int Color)
{
	_BColor = Color;
}

void _Menu::SetFColor(int Color)
{
	_FColor = Color;
}