// _Screen.h: interface for the _Screen class.
//
//////////////////////////////////////////////////////////////////////

class _Screen  
{
protected:
	int	_Mode,	// _Screen Mode
		_MaxX,	// Max Column
		_MaxY,	// Max Row
		_Attribute;	// Attribute
	char *_ScrBuffer;	// Stores whole screen into buffer
	int _ScrLeft,	// X1 origin of screen buffer
		_ScrTop,	// Y1 origin of screen buffer
		_ScrRight,	// X2 origin of screen buffer
		_ScrBottom;	// Y2 origin of screen buffer
	void _UpdateInfo();	// Update variables according to current _Screen mode
public:

	_Screen();
	virtual ~_Screen();	
	
	int X() const;	// Return current column
	int Y() const;	// Return current row
	int MaxX() const;	// Return max column
	int MaxY() const;	// Return max row
	int Attribute() const;	// Return attribute
	int Mode() const;	// Return current screen mode
	void SetMode(int Mode);	// Set _Screen mode and initialize Screen (Reference @ bottom of page)
	void GotoXY(int X, int Y) const;	// Place cursor at X,Y
	void GetScreen();	// Stores full screen into buffer;
	void GetScreen(int Left, int Top, int Right, int Bottom);	// Stores portion of screen into buffer
	void PutScreen() const;	// Restores buffered screen display
	void Fill(int Color);	// Fills screen with specified color
	void Cls(int Color);	// Clears screen with current background color
	void Cll(int Color);	// Clears current line
	void Cll(int Line, int Color);	// Clears specified line
	void PutText(int Left, int Top, int FGColor, int BGColor, char *);	// Puts text at location Left,Top with xxColor
	void PutTextCenter(int Left, int Top, int Width, int FGColor, int BGColor, char *Text);
	void SetColor(int Color) const;	// Sets text color
	void SetBackGround(int Color) const;	// Sets background color
	void MoveText(int Left, int Top, int Right, int Bottom, int tLeft, int tTop);
};
	    
/*	_Screen Mode Reference
	===================

	Special Modes			Color Modes
	-------------			-----------
	LASTMODE	= -1		C40X14		= 8			C80X21		= 15
	BW40		= 0			C40X21		= 9			C80X28		= 16
	C40			= 1			C40X28		= 10		C80X43		= 17
	BW80		= 2			C40X43		= 11		C80X50		= 18
	C80			= 3			C40X50		= 12		C80X60		= 19
	MONO		= 7			C40X60		= 13
	C4350		= 64		C80X14		= 14
    
	Black & White Modes
	-------------------  
	BW40X21		= 21		BW80X14		= 26
	BW40X28		= 22		BW80X21		= 27
	BW40X43		= 23		BW80X28		= 28
	BW40X50		= 24		BW80X43		= 29
	BW40X60		= 25		BW80X50		= 30
							BW80X60		= 31
   
	New Monochrome Modes
	--------------------
	MONO14		= 32	// Invalid VGA mode
	MONO21		= 33
	MONO28		= 34
	MONO43		= 35
	MONO50		= 36
	MONO60		= 37

	_ORIGMODE	= 65	// original mode at program startup 
*/