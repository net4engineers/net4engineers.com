// _MenuItem.cpp: implementation of the _MenuItem class.
//
//////////////////////////////////////////////////////////////////////

#include "_MenuItem.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

_MenuItem::_MenuItem()
{
	_IsBar = 0;
	Next = Previous = NULL;
	_Name = NULL;
	_Exe = NULL;
	_ID = Len = _X = _Y = _HColor = _FColor = _BColor
		= _Width = _HighLight = _SFColor = _SBColor = 0;
	_Selected = _HighLight = 0;
	_SKey = '\0';
}

_MenuItem::~_MenuItem()
{
	if (_Name != NULL)
		delete [] _Name;
}

int _MenuItem::ID() const
{
	return _ID;
}

char* _MenuItem::Name() const
{
	return _Name;
}

void _MenuItem::SetExe(void (&Function)())
{
	_Exe = Function;
}

int _MenuItem::SFColor() const
{
	return _SFColor;
}

_MenuItem _MenuItem::operator =(_MenuItem &rhs)
{

	SetName(rhs.Name());
	SetBColor(rhs.BColor());
	_Exe = rhs._Exe;
	SetFColor(rhs.FColor());
	SetHColor(rhs.HColor());
	SetID(rhs.ID());
	SetSBColor(rhs.SBColor());
	SetSFColor(rhs.SFColor());
	SetXY(rhs.X(), rhs.Y());
	SetWidth(rhs.Width());
	Next = rhs.Next;
	Previous = rhs.Previous;
	return *this;
}

int _MenuItem::SBColor() const
{
	return _SBColor;
}

void _MenuItem::SetID(int ID)
{
	_ID = ID;
}

void _MenuItem::SetName(char *Name)
{
	Len = 0;
	if (Name[0] != '-')
	{
		while (Name[Len] != '\0')
			Len++;
		if (_Name != NULL)
			delete [] _Name;
		_Name = new char[Len + 1];
		int i;
		for (i = 0; i < Len; i++)
		{
			if (_Name[i] == '&')
			{
				_SKey = _Name[++i];
				i--;
			}
			_Name[i] = Name[i];
		}
		_Name[i] = '\0';
	}
	else
	{
		Len = 16;
		if (_Name != NULL)
			delete [] _Name;
		_Name = new char[Len + 1];
		int i;
		for (i = 0; i < Len; i++)
			_Name[i] = 196;
		_Name[i] = '\0';
		_IsBar = 1;
	}
}

void _MenuItem::SetXY(int X, int Y)
{
	_X = X;
	_Y = Y;
}

int _MenuItem::Width() const
{
	return _Width;
}

void _MenuItem::SetSBColor(int Color)
{
	_SBColor = Color;
}

void _MenuItem::SetSFColor(int Color)
{
	_SFColor = Color;
}

void _MenuItem::SetWidth(int Width)
{
	_Width = Width;
}

int _MenuItem::X() const
{
	return _X;
}

int _MenuItem::Y() const
{
	return _Y;
}

int _MenuItem::HColor() const
{
	return _HColor;
}

void _MenuItem::Draw()
{
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X - 1, _Y);
	if (IsBar())
		cprintf("%c", 195);
	else
		cprintf("%c", 179);
	if (!IsBar())
		cprintf(" ");
	int i;
	for (i = 0; i < Len; i++)
	{
		if (_Name[i] == '&')
			i++;
		cprintf("%c", _Name[i]);
	}
	for (i = 0; i < _Width - Len; i++)
		cprintf(" ");
	if (IsBar())
		cprintf("%c", 180);
	else
		cprintf("%c", 179);
	Screen->SetColor(BLACK);
	cprintf("%c%c", 219, 219);
}

bool _MenuItem::HighLight() const
{
	if (_HighLight)
		return 1;
	else
		return 0;
}

void _MenuItem::HighLightOff()
{
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X, _Y);
	if (!IsBar())
		cprintf(" ");
	int i;
	for (i = 0; i < Len; i++)
	{
		if (_Name[i] == '&')
			i++;
		cprintf("%c", _Name[i]);
	}
	for (i = 0; i < _Width - Len; i++)
		cprintf(" ");
	_HighLight = 0;
}

void _MenuItem::HighLightOn()
{
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X, _Y);
	if (!IsBar())
		cprintf(" ");
	int i;
	for (i = 0; i < Len; i++)
	{
		if (_Name[i] == '&')
		{
			Screen->SetColor(_HColor);
			i++;
			cprintf("%c", _Name[i]);
			_SKey = _Name[i];
			Screen->SetColor(_FColor);
			continue;
		}
		cprintf("%c", _Name[i]);
	}
	for (i = 0; i < _Width - Len; i++)
		cprintf(" ");
	_HighLight = 1;
}

void _MenuItem::Execute() const
{
	_Exe();
}

int _MenuItem::FColor() const
{
	return _FColor;
}

int _MenuItem::BColor() const
{
	return _BColor;
}

void _MenuItem::SetHColor(int Color)
{
	_HColor = Color;
}

bool _MenuItem::IsBar() const
{
	if (_IsBar)
		return 1;
	else 
		return 0;
}

bool _MenuItem::Selected() const
{
	if (_Selected)
		return 1;
	else 
		return 0;
}

void _MenuItem::SelectOn()
{
	Screen->SetColor(_SFColor);
	Screen->SetBackGround(_SBColor);
	Screen->GotoXY(_X, _Y);
	int CurPos = _X;
	if (!IsBar())
		cprintf(" ");
	int i;
	for (i = 0; i < Len; i++)
	{
		if (_Name[i] == '&')
		{
			CurPos = Screen->X();
			Screen->SetColor(_HColor);
			cprintf("%c", _Name[++i]);
			Screen->SetColor(_SFColor);
			continue;
		}
		cprintf("%c", _Name[i]);
	}
	for (i = 0; i < _Width - Len; i++)
		cprintf(" ");
	_HighLight = 1;
	_Selected = 1;
	Screen->GotoXY(CurPos, _Y);
}

void _MenuItem::SelectOff()
{
	HighLightOn();
	_Selected = 0;
}

void _MenuItem::SetBColor(int Color)
{
	_BColor = Color;
}

void _MenuItem::SetFColor(int Color)
{
	_FColor = Color;
}
