/-----------------------------------------------------------\
		Console Menu Foundation Class Readme
\-----------------------------------------------------------/

Package files:
  01/11/2000  05:07p	1,143 _Menu.h		Menu
  30/10/2000  09:00p	4,681 _Menu.cpp
  30/10/2000  09:00p	1,367 _MenuHeader.h	Sub menu file ...
  30/10/2000  09:00p	8,352 _MenuHeader.cpp	
  30/10/2000  08:58p	1,251 _MenuItem.h		Sub menu file ...
  30/10/2000  08:58p	4,976 _MenuItem.cpp	
  01/11/2000  04:00p	2,716 _Screen.h		Manipulates text mode
  01/11/2000  04:00p	4,553 _Screen.cpp		
  01/11/2000  10:49p	67,072 Driver.exe		Driver bin
  01/11/2000  10:49p    1,559 Driver.cpp		Driver source code
  27/09/2000  10:08p    699 Readme.txt		This file
				ScreenShot.gif		Screen shot file
	     11 File(s)   98,369 bytes

This program demostrates how to create a console menu
foundation class.  With this, you can create menus in 
seconds!

-----------------
