// _MenuHeader.cpp: implementation of the _MenuHeader class.
//
//////////////////////////////////////////////////////////////////////

#include "_MenuHeader.h"
#ifndef ESC
	#define ESC       0x1b
#endif
#ifndef UP
	#define UP        72
#endif
#ifndef DOWN
	#define DOWN      80
#endif
#ifndef LEFT
	#define LEFT      75
#endif
#ifndef RIGHT
	#define RIGHT     77
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

_MenuHeader::_MenuHeader()
{
	Next = Previous = NULL;
	Head = Current = Tail = NULL;
	_Name = NULL;
	_ID = _Len = _X = _Y = _HColor = _FColor = _BColor
		= _Width = _HighLight = _SFColor = _SBColor = 0;
	_Selected = _HighLight = 0;
	_SKey = '\0';
	_TotalItems = 0;
	_Width = 0;
	_Shown = 0;
}

_MenuHeader::~_MenuHeader()
{
	Current = Head;
	while (Current != NULL)
	{
		Current = Current->Next;
		delete Head;
		Head = Current;
	}
	Head = Current = Tail = NULL;	
	if (_Name != NULL)
		delete [] _Name;
	if (_Name != NULL)
		delete [] _Name;
}

void _MenuHeader::Show()
{
	Screen->GetScreen(_X - 1, _Y, _X + 20, _Y + _TotalItems + 1 + 2);
	SelectOn();
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X - 1, _Y + 1);
	char *Temp = new char[100];
	int i = 0;
	Temp[i] = 218;
	for (i = 1; i < 17; i++)
		Temp[i] = 196;
	Temp[i++] = 191;
	Temp[i] = '\0';
	cprintf("%s", Temp);

	Current = Head;
	while (Current != NULL)
	{
		Current->Draw();
		Current->HighLightOn();;
		Current = Current->Next;
	}

	Screen->GotoXY(_X - 1, Screen->Y() + 1);
	i = 0;
	Temp[i] = 192;
	for (i = 1; i < 17; i++)
		Temp[i] = 196;
	Temp[i++] = 217;
	Temp[i] = '\0';
	cprintf("%s", Temp);
	putch(219);
	putch(219);
	for (i = 0; i < 19; i++)
		Temp[i] = 219;
	Temp[i] = '\0';
	Screen->GotoXY(_X, Screen->Y() + 1);
	cprintf("%s", Temp);
	delete [] Temp;
	_Shown = 1;
	if (Head != NULL)
		Head->SelectOn();
}

void _MenuHeader::Hide()
{
	SelectOff();
	HighLightOff();
	Screen->PutScreen();
	_Shown = 0;
}

bool _MenuHeader::Shown() const
{
	if (_Shown)
		return 1;
	else
		return 0;
}

void _MenuHeader::SortItems()
{
	_MenuItem *Left, *Right, *Temp;
	Left = Right = Head;
	while (Left != NULL)
	{
		while (Right != NULL)
		{
			if (Right->ID() < Left->ID())
			{
				Temp = new _MenuItem;
				Temp->Next = Left->Next;
				Temp->Previous = Left->Previous;
				Temp->SetID(Left->ID());

				Left->Next = Right->Next;
				Left->Previous = Right->Previous;
				Left->SetID(Right->ID());

				Right->Next = Temp->Next;
				Right->Previous = Temp->Previous;
				Right->SetID(Temp->ID());
				delete Temp;
			}
			Right = Right->Next;
		}
		Left = Left->Next;
		Right = Left;
	}
}

int _MenuHeader::TotalItems() const
{
	return _TotalItems;
}

int _MenuHeader::ID() const
{
	return _ID;
}

int _MenuHeader::Len() const
{
	return _Len;
}

char* _MenuHeader::Name() const
{
	return _Name;
}

int _MenuHeader::SFColor() const
{
	return _SFColor;
}

int _MenuHeader::Run()
{
	int Input;
	bool _Exit = false;
	Show();
	Current = Head;
	while (1)
	{
		Input = getch();
		switch(Input)
		{
		case ESC:
			Hide();
			Input = 0;
			_Exit = true;
			break;
		case UP:
			while (1)
			{
				Current->SelectOff();
				if (Current->Previous == NULL)
					Current = Tail;
				else
					Current = Current->Previous;
				Current->SelectOn();
				if (Current->IsBar())
					continue;
				else
					break;
			}
			Input = 0;
			break;
		case DOWN:
			while (1)
			{
				Current->SelectOff();
				if (Current->Next == NULL)
					Current = Head;
				else
					Current = Current->Next;
				Current->SelectOn();
				if (Current->IsBar())
					continue;
				else
					break;
			}
			Input = 0;
			break;
		case LEFT:
			Hide();
			Input = -1;
			_Exit = true;
			break;
		case RIGHT:
			Hide();
			Input = 1;
			_Exit = true;
			break;
		case '\r':
			Hide();
			Current->Execute();
			Input = 0;
			_Exit = true;
			break;
		default:
			break;
		}
		if (_Exit)
			break;
	}
	return Input;
}

int _MenuHeader::SBColor() const
{
	return _SBColor;
}

void _MenuHeader::SetID(int ID)
{
	_ID = ID;
}

void _MenuHeader::SetName(char *Name)
{
	_Len = 0;
	while (Name[_Len] != '\0')
		_Len++;
	if (_Name != NULL)
		delete [] _Name;
	_Name = new char[_Len + 1];
	int i;
	for (i = 0; i < _Len; i++)
	{
		if (_Name[i] == '&')
		{
			_SKey = _Name[++i];
			i--;
		}
		_Name[i] = Name[i];
	}
	_Width = _Len + 1;
}

void _MenuHeader::SetXY(int X, int Y)
{
	_X = X;
	_Y = Y;
}

int _MenuHeader::Width() const
{
	return _Width;
}

void _MenuHeader::SetSBColor(int Color)
{
	_SBColor = Color;
}

void _MenuHeader::SetSFColor(int Color)
{
	_SFColor = Color;
}

int _MenuHeader::X() const
{
	return _X;
}

int _MenuHeader::Y() const
{
	return _Y;
}

int _MenuHeader::HColor() const
{
	return _HColor;
}

void _MenuHeader::Draw()
{
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X, _Y);
	cprintf(" ");
	int i;
	for (i = 0; i < _Len; i++)
	{
		if (_Name[i] == '&')
			i++;
		cprintf("%c", _Name[i]);
	}
	cprintf(" ");
}

bool _MenuHeader::HighLight() const
{
	if (_HighLight)
		return 1;
	else
		return 0;
}

void _MenuHeader::HighLightOff()
{
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X, _Y);
	cprintf(" ");
	int i;
	for (i = 0; i < _Len; i++)
	{
		if (_Name[i] == '&')
			i++;
		cprintf("%c", _Name[i]);
	}
	cprintf(" ");
	_HighLight = 0;
}

void _MenuHeader::HighLightOn()
{
	Screen->SetColor(_FColor);
	Screen->SetBackGround(_BColor);
	Screen->GotoXY(_X, _Y);
	cprintf(" ");
	int i;
	for (i = 0; i < _Len; i++)
	{
		if (_Name[i] == '&')
		{
			Screen->SetColor(_HColor);
			i++;
			cprintf("%c", _Name[i]);
			_SKey = _Name[i];
			Screen->SetColor(_FColor);
			continue;
		}
		cprintf("%c", _Name[i]);
	}
	cprintf(" ");
	_HighLight = 1;
}

int _MenuHeader::FColor() const
{
	return _FColor;
}

void _MenuHeader::AddBar()
{
	Current = new _MenuItem;
	if (Head == NULL)
	{
		Head = Tail = Current;
		Head->Previous = NULL;
		Tail->Next = NULL;
	}
	else
	{
		Tail->Next = Current;
		Current->Previous = Tail;
		Tail = Current;
		Tail->Next = NULL;
	}
	Current->SetName("-");
	Current->SetBColor(_BColor);
	Current->SetFColor(_FColor);
	Current->SetHColor(_HColor);
	Current->SetSBColor(_SBColor);
	Current->SetSFColor(_SFColor);
	Current->SetWidth(16);
	_TotalItems++;
	Current->SetXY(_X, _Y + _TotalItems + 1);
}

void _MenuHeader::AddItem(int ID, char *Name, void (*Function)())
{
	Current = new _MenuItem;
	if (Head == NULL)
	{
		Head = Tail = Current;
		Head->Previous = NULL;
		Tail->Next = NULL;
	}
	else
	{
		Tail->Next = Current;
		Current->Previous = Tail;
		Tail = Current;
		Tail->Next = NULL;
	}
	Current->SetName(Name);
	Current->SetExe(Function);
	Current->SetBColor(_BColor);
	Current->SetFColor(_FColor);
	Current->SetHColor(_HColor);
	Current->SetID(ID);
	Current->SetSBColor(_SBColor);
	Current->SetSFColor(_SFColor);
	Current->SetWidth(16);
	_TotalItems++;
	Current->SetXY(_X, _Y + _TotalItems + 1);
//	SortItems();
}

int _MenuHeader::BColor() const
{
	return _BColor;
}

void _MenuHeader::SetHColor(int Color)
{
	_HColor = Color;
}

bool _MenuHeader::Selected() const
{
	if (_Selected)
		return 1;
	else 
		return 0;
}

void _MenuHeader::SelectOn()
{
	Screen->SetColor(_SFColor);
	Screen->SetBackGround(_SBColor);
	Screen->GotoXY(_X, _Y);
	int CurPos = _X;
	cprintf(" ");
	int i;
	for (i = 0; i < _Len; i++)
	{
		if (_Name[i] == '&')
		{
			CurPos = Screen->X();
			Screen->SetColor(_HColor);
			cprintf("%c", _Name[++i]);
			Screen->SetColor(_SFColor);
			continue;
		}
		cprintf("%c", _Name[i]);
	}
	cprintf(" ");
	_HighLight = 1;
	_Selected = 1;
	Screen->GotoXY(CurPos, _Y);
}

void _MenuHeader::SelectOff()
{
	HighLightOn();
	_Selected = 0;
}

void _MenuHeader::SetBColor(int Color)
{
	_BColor = Color;
}

void _MenuHeader::SetFColor(int Color)
{
	_FColor = Color;
}
