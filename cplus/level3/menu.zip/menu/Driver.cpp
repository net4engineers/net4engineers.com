#include "_Screen.cpp"
#include "_Menu.cpp"

bool END_OF_PROGRAM = false;

void DoNothing() {}
void FileExit() { END_OF_PROGRAM = true; }
	
_Screen *Screen = new _Screen;
_Menu *Menu = new _Menu;

int main()
{
	// Screen Setups
	Screen->SetMode(C80X50);
	Screen->Fill(BLUE);
	Screen->Cll(1, LIGHTGRAY);	// Clear line with color:lightgray
	Screen->Cll(50, LIGHTGRAY);
	Screen->PutText(2, 50, RED, LIGHTGRAY, "Esc = Menu");
	
	// Menu Setups
	Menu->SetName("&Menu1");
	Menu->SetFColor(BLACK);
	Menu->SetBColor(LIGHTGRAY);
	Menu->SetHColor(YELLOW);
	Menu->SetSBColor(BLACK);
	Menu->SetSFColor(WHITE);
	Menu->SetXY(1,1);
	
	// FILE MENU
	Menu->AddItem(0, "&File");
	Menu->AddSubMenuItem(0, 1, "&Open", DoNothing);
	Menu->AddSubMenuItem(0, 2, "&Close", DoNothing);
	Menu->AddSubMenuBar(0);
	Menu->AddSubMenuItem(0, 4, "Save &As...", DoNothing);
	Menu->AddSubMenuBar(0);
	Menu->AddSubMenuItem(0, 5, "&Print", DoNothing);
	Menu->AddSubMenuBar(0);
	Menu->AddSubMenuItem(0, 6, "E&xit", FileExit);

	// Search MENU
	Menu->AddItem(3, "&Search");
	Menu->AddSubMenuItem(3, 0, "&Find...", DoNothing);
	
	// HELP MENU
	Menu->AddItem(5, "&Help");
	Menu->AddSubMenuItem(5, 0, "&Commands...", DoNothing);
	Menu->AddSubMenuItem(5, 1, "&About...", DoNothing);
	
	Menu->Draw();

	int ch;
	while (1)
	{
		Screen->GotoXY(1, 2);
		ch = getch();
		switch(ch)
		{
		case 0x1b:	// ESC
			Menu->Run();
			break;	
		default:
			break;
		}
		if (END_OF_PROGRAM)
			break;
	}
	delete Screen;
	delete Menu;
	return 0;
}
