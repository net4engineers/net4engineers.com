// _MenuItem.h: interface for the _MenuItem class.
//
//////////////////////////////////////////////////////////////////////

extern _Screen *Screen;

class _MenuItem  
{
protected:
	int _ID;
	char *_Name;
	int Len;
	int _X;
	int _Y;
	int _HColor;
	int _FColor;
	int _BColor;
	int _SFColor;
	int _SBColor;
	int _Width;
	char _SKey;
	bool _Selected;
	bool _HighLight;
	bool _IsBar;
public:
	_MenuItem *Next;
	_MenuItem *Previous;
	_MenuItem();
	virtual ~_MenuItem();

	void (*_Exe)();
	int X() const;
	int Y() const;
	int ID() const;
	int Width() const;
	void SetWidth(int Width);
	char *Name() const;
	bool IsBar() const;
	void SetXY(int X, int Y);
	void SetName(char *Name);
	void SetExe(void (&Function)());
	int BColor() const;
	int FColor() const;
	int HColor() const;
	int SFColor() const;
	int SBColor() const;
	void SetID(int ID);
	void SetSFColor(int Color);
	void SetSBColor(int Color);
	void SetFColor(int Color);
	void SetBColor(int Color);
	void SetHColor(int Color);
	void Execute() const;
	bool HighLight() const;
	void HighLightOn();
	void HighLightOff();
	bool Selected() const;
	void SelectOn();
	void SelectOff();
	void Draw();

	_MenuItem operator=(_MenuItem &rhs);
};
