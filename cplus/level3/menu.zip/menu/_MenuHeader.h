// _MenuHeader.h: interface for the _MenuHeader class.
//
//////////////////////////////////////////////////////////////////////

#include "_MenuItem.cpp"
extern _Screen *Screen;

class _MenuHeader  
{
protected:
	int _ID;
	char *_Name;
	int _Len;
	int _X;
	int _Y;
	int _HColor;
	int _FColor;
	int _BColor;
	int _SFColor;
	int _SBColor;
	int _Width;
	char _SKey;
	bool _Selected;
	bool _HighLight;
	int _TotalItems;
	bool _Shown;
	_MenuItem *Head, *Current, *Tail;
public:
	_MenuHeader *Next, *Previous;
	_MenuHeader();
	virtual ~_MenuHeader();
	
	int X() const;
	int Y() const;
	int ID() const;
	int Width() const;
	int Len() const;
	char *Name() const;
	void SetXY(int X, int Y);
	void SetName(char *Name);
	int BColor() const;
	int FColor() const;
	int HColor() const;
	int SFColor() const;
	int SBColor() const;
	void SetID(int ID);
	void SetSFColor(int Color);
	void SetSBColor(int Color);
	void SetFColor(int Color);
	void SetBColor(int Color);
	void SetHColor(int Color);
	bool HighLight() const;
	void HighLightOn();
	void HighLightOff();
	bool Selected() const;
	bool Shown() const;
	void SelectOn();
	void SelectOff();
	int TotalItems() const;
	void AddBar();
	void AddItem(int ID, char *Name, void (*Function)());
	void SortItems();
	void Draw();
	void Show();
	void Hide();
	int Run();
};