// _Screen.cpp: implementation of the _Screen class.
//
//////////////////////////////////////////////////////////////////////

#include <conio.h>
#include "_Screen.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

_Screen::_Screen()
{
	_ScrBuffer = NULL;
	_UpdateInfo();
}

_Screen::~_Screen()
{
	if (_ScrBuffer != NULL)
		delete [] _ScrBuffer;
//	SetMode(_ORIGMODE);
}

//////////////////////////////////////////////////////////////////////
// Functions
//////////////////////////////////////////////////////////////////////

int _Screen::Attribute() const
{
	return _Attribute;
}

void _Screen::Cll(int Color)
{
	_UpdateInfo();
	textbackground(Color);
	gotoxy(1, wherey());
	clreol();
	_UpdateInfo();
	textattr(_Attribute);
}

void _Screen::Cll(int Line, int Color)
{
	_UpdateInfo();
	textbackground(Color);
	int OrigX = wherex(),
		OrigY = wherey();
	gotoxy(1, Line);
	clreol();
	gotoxy(OrigX, OrigY);

	textattr(_Attribute);
}

void _Screen::Cls(int Color)
{
	_UpdateInfo();
	textbackground(Color);
	clrscr();
	textattr(_Attribute);
}

void _Screen::GotoXY(int X, int Y) const
{
	if ((X >= 1 && X <= _MaxX) && (Y >= 1 && Y <= _MaxY))
		gotoxy(X, Y);
}

void _Screen::Fill(int Color)
{
	_UpdateInfo();
	textbackground(Color);
	clrscr();
	textattr(_Attribute);
}

void _Screen::GetScreen()
{
	if (_ScrBuffer != NULL)
		delete [] _ScrBuffer;
	_ScrBuffer = new char[_MaxX * _MaxY * 2 + 1];
	gettext(1, 1, _MaxX, _MaxY, _ScrBuffer);
	_ScrLeft = _ScrTop = 1;
	_ScrRight = _MaxX;
	_ScrBottom = _MaxY;
}

void _Screen::GetScreen(int Left, int Top, int Right, int Bottom)
{
	if (Left >= 1 && 
		Left <= Right && 
		Right <= _MaxX && 
		Right >= Left &&
		Top >= 1 &&
		Top <= Bottom &&
		Bottom <= _MaxY
		)
	{
		if (_ScrBuffer != NULL)
			delete [] _ScrBuffer;
		_ScrBuffer = new char[Right * Bottom * 2 + 1];
		gettext(Left, Top, Right, Bottom, _ScrBuffer);
		_ScrLeft = Left;
		_ScrTop = Top;
		_ScrRight = Right;
		_ScrBottom = Bottom;
	}
}

void _Screen::MoveText(int Left, int Top, int Right, int Bottom, int tLeft, int tTop)
{
	movetext(Left, Top, Right, Bottom, tLeft, tTop);
}

void _Screen::PutScreen() const
{
	if (_ScrBuffer != NULL)
	{
		puttext(_ScrLeft, _ScrTop, _ScrRight, _ScrBottom, _ScrBuffer);
	}
}

	

int _Screen::MaxX() const
{
	return _MaxX;
}

int _Screen::MaxY() const
{
	return _MaxY;
}

int _Screen::Mode() const
{
	return _Mode;
}

void _Screen::PutText(int Left, int Top, int FGColor, int BGColor, char *Text)
{
	if (Left >= 1 && Left <= _MaxX &&
		Top >= 1 && Top <= _MaxY
		)
	{
		int OrigX = wherex(),
			OrigY = wherey();
		_UpdateInfo();
		textcolor(FGColor);
		textbackground(BGColor);
		gotoxy(Left, Top);
		unsigned long ParsedTxtSize = 0;
		while (Text[ParsedTxtSize] != '\0')
			ParsedTxtSize++;
		char *ParsedTxt = new char[ParsedTxtSize * 2];
		unsigned long i = 0;
		ParsedTxtSize = 0;
		while (Text[ParsedTxtSize] != '\0')
		{
			if (Text[ParsedTxtSize] == '\n')
			{
				ParsedTxt[i++] = '\n';
				ParsedTxt[i++] = '\r';
				ParsedTxtSize++;
				continue;
			}
			ParsedTxt[i++] = Text[ParsedTxtSize++];
		}
		ParsedTxt[i] = '\0';
		cprintf("%s", ParsedTxt);
		delete [] ParsedTxt;
		textattr(_Attribute);
		gotoxy(OrigX, OrigY);
	}
}

void _Screen::PutTextCenter(int Left, int Top, int Width, int FGColor, int BGColor, char *Text)
{
	if (Left >= 1 && Left <= _MaxX &&
		Top >= 1 && Top <= _MaxY
		)
	{
		int OrigX = wherex(),
			OrigY = wherey();
		_UpdateInfo();
		textcolor(FGColor);
		textbackground(BGColor);
		Cll(Top, BGColor);
		unsigned int len = 0;
		while (Text[len] != '\0')
			len++;
		gotoxy(Left + (Width - len) / 2, Top);
		cprintf("%s", Text);
		textattr(_Attribute);
		gotoxy(OrigX, OrigY);
	}
}

void _Screen::SetColor(int Color) const
{
	textcolor(Color);
}

void _Screen::SetBackGround(int Color) const
{
	textbackground(Color);
}

void _Screen::SetMode(int Mode)
{
	_Mode = Mode;
	textmode(_Mode);
	_UpdateInfo();
}

void _Screen::_UpdateInfo()
{
	struct text_info _Text_Info;
	gettextinfo(&_Text_Info);
	_MaxX = _Text_Info.screenwidth;
	_MaxY = _Text_Info.screenheight;
	_Attribute = _Text_Info.attribute;
	_Mode = _Text_Info.currmode;
}

int _Screen::X() const
{
	return wherex();
}

int _Screen::Y() const
{
	return wherey();
}