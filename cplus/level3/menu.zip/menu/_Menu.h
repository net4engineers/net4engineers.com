// _Menu.h: interface for the _Menu class.
//
//////////////////////////////////////////////////////////////////////

#include "_MenuHeader.cpp"
extern _Screen *Screen;

class _Menu		
{
protected:
	int _ID;
	char *_Name;
	int Len;
	int _X;
	int _Y;
	int _HColor;
	int _FColor;
	int _BColor;
	int _SFColor;
	int _SBColor;
	char _SKey;
	int _TotalMenus;
	int _MenuLen;
	int _HighLight;
	int _NextPos;
	_MenuHeader *Head, *Current, *Tail;
public:
	_Menu();
	virtual ~_Menu();

	int X() const;
	int Y() const;
	int ID() const;
	char *Name() const;
	void SetXY(int X, int Y);
	void SetName(char *Name);
	int BColor() const;
	int FColor() const;
	int HColor() const;
	int SFColor() const;
	int SBColor() const;
	void SetID(int ID);
	void SetSFColor(int Color);
	void SetSBColor(int Color);
	void SetFColor(int Color);
	void SetBColor(int Color);
	void SetHColor(int Color);
	int TotalMenus() const;
	void AddItem(int ID, char *Name);
	void AddSubMenuItem(int MenuID, int SubMenuID, char *Name, void (*Function)());
	void AddSubMenuBar(int MenuID);
	void SortMenus();
	void Draw();
	int Run();
};