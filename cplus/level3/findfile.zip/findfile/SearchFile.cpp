#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <alloc.h>
#include <dir.h>
#include <dos.h>

#ifndef __cplusplus
typedef enum { false, true } bool;
#endif

struct tagTSTRLIST
{
    int max;
    int count;
    char** str;
} TStrList;

// Create the string list
TStrList* InitStrList()
{
    // Create and initiate the list
    TStrList* strList = (TStrList*)malloc(sizeof(TStrList));
    if (strList)
    {
        strlist->count = 0;
        strlist->max = 0;
        strlist->str = 0;
    }

    return strlist;
}

// Add strings in a string list
TStrList* AddStr(TStrList* strlist, char* str)
{
    char** temp;

    // if overflow, expand the list
    if (strlist->count >= strlist->max)
    {
        temp = (char**)realloc(strlist->str, sizeof(char*) * (strlist->max + 10));
        if (temp)
        {
            strlist->max += 10;
            strlist->str = temp;
        }
        else
            return strlist;
    }

    // Duplicate the string and add in the list
    strlist->str[strlist->count++] = strdup(str);

    return strlist;
}

// Search files through a base dir
void SearchFile(const char* path, const char *file)
{
    TStrList* dirlist = InitStrList();
    ffblk ffblk;    // Struct ffblk (dos.h)
    bool found;
    char curpath[MAXPATH];

    printf("Directory: %s\n", path);

    fnmerge(curpath, 0, path, "*.*", 0);

    // Create a list of subdirs
    found = findfirst(curpath, &ffblk, FA_DIREC) == 0;
    while (found)
    {
        if ((strcmp(ffblk.ff_name, ".") != 0) &&
            (strcmp(ffblk.ff_name, "..") != 0) &&
            (ffblk.ff_attrib == FA_DIREC))
        {
            AddStr(dirlist, ffblk.ff_name);
        }

        found = findnext(&ffblk) == 0;
    }

    fnmerge(curpath, 0, path, file, 0);

    // Search the files
    found = findfirst(curpath, &ffblk, FA_ARCH) == 0;
    while (found)
    {
        printf("  File:    %s\n", ffblk.ff_name);
        found = findnext(&ffblk) == 0;
    }

    // If found subdirs, use recursive
    if (dirlist->count)
    {
        int c;

        for(c = 0; c < dirlist->count; c++)
        {
            fnmerge(curpath, 0, path, dirlist->str[c], 0);
            SearchFile(curpath, file);

            free(dirlist->str[c];
        }

        free(dirlist->str);
    }
    free(dirlist);
}

void main(int argc, char* argv[])
{
    printf("SearchFile - GPSistemas 2000\n");
    switch(argc)
    {
        case 3:
            SearchFile(argv[1], argv[2]);
            break;
        case 2:
            SearchFile("", argv[1]);
            break;
        default:
            printf("Use: SearchFile [path] filename\n"
                   "     path     - drive:\\directory\\, initial path, no wildcards allowed\n"
                   "     filename - filename.ext, you may use wildcards\n");
    }
}

