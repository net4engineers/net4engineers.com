#include <iostream.h>
#include <conio.h>
#include <iomanip.h>
#include <fstream.h>
#include <stdlib.h>
#include <dir.h>

#include "Manager.h"
Account_Manager AM;

//These are all the functions used
void Deposit(int bal);
void Withdrawal(int bal);
void Balance(int bal);
void AccManager();
void Menu();
void FinOrganizer();
void Exit();

//These are the variables used
int Dnum;
int bal;
char select;


int main(){
    //This function clears the screen everytime the program comes back to
    //the main menu function.
//  clrscr();
    //Main menu function
    Menu();

    return 0;
    }
    //The deposit function handles deposits coming into the program
void Deposit(){
     clrscr();

     cout <<"\n\tEnter an amount: $";
     cin >>Dnum;

     /*The balance is read from the Bank file and is added to the amount
     deposited. When starting the program for the first time the bal will
     be 0, but when a deposit amount is given, it is added to the bal so
     the next time the bal is read from the Bank file it will be what
     was added to the bal which was 0 and now the balance becomes the
     first deposit and the process continues every time a deposit is made.*/

     ifstream balin("Bank.tcd");
     balin>>bal;
     balin.close();

     bal = bal + Dnum;

     /*If someone tries to enter an amount which is valid like 0 the program
     does not process it. Otherwise it adds it to the bal and displays the
     amount deposited and also the new balance.*/



     if(Dnum != 0){
	
     ofstream Depo("Bank.tcd");
     Depo<<bal;
     Depo.close();

     cout <<"\n\tAmount deposited: $"<<Dnum<<endl;
     cout <<"\n\n\tYour balance is now: $"<<bal<<endl;

     }else{     
      cout<<"\n\tIncorrect amount, try again."<<endl;
	  getch();
	  AccManager();
	  
     }
    
     cout <<"\n\n\tPress any key to contine..."<<endl;
     getch();
	AccManager();
		
       }
      //The Withdrawal function is what it says it is. It withdraws any amount
      //entered but will not minus the account.
void Withdrawal(){
     clrscr();
     int Wnum;


     cout <<"\n\tEnter an amount: ";
     cin >>Wnum;

     if(Wnum != 0){
     ifstream Without("Bank.tcd");
     Without>>bal;
     Without.close();

     bal = bal - Wnum;

     if(bal < 0){
     cout <<"Your account can not be minus, please enter another amount."<<endl;
     getch();
     Withdrawal();
     }

     ofstream Within("Bank.tcd");
     Within<<bal;
     Within.close();

     }
     cout <<"\n\n\tAmount withdrewed: $"<<Wnum;
     cout <<"\n\n\tYour balance is now: $"<<bal;

     cout <<"\n\n\tPress any key to continue..."<<endl;
     getch();
     AccManager();
     }

     //The balance function displays what ever amount is in the Bank file
void Balance(){
     clrscr();
     bal;


     ifstream Balout("Bank.tcd");
     Balout>>bal;
     Balout.close();

     /*This "if" function compares the value of the bal integer and if
     it contains this number 2408428 it sets it to 0. I did this because,
     when I started writing this program the value of bal keep on reseting
     to 2408428 which is the amount of an integer value on my
     computer(yours maybe different). Though the problem is fixed now
     I still use this test to make sure that it does not happen again. You
     may want to change it because if someone enters an amount greater than
     this number, yes, the program is going to reset the value of balance.*/

     if(bal > 2408428){
     bal = 0;
     }
     ofstream Balin("Bank.tcd");
     Balin<<bal;
     Balin.close();

     cout <<"\n\tYour current balance is: "<<bal;
     cout <<"\n\nPress any key to continue..."<<endl;
     getch();
     AccManager();
     }

     //This is the overall main menu list
void Menu(){
     clrscr();

     cout <<"\t\t\tMain Menu"<<endl;
     cout <<"\t\t\t========="<<endl;

     cout <<"\n\n\t1) Account Manager"<<endl;
     cout <<"\n\t2) Finance Organizer"<<endl;
     cout <<"\n\t3) Quit"<<endl;

     cout <<"\n\n\tEnter selection: ";
     cin >>select;

     if(select == '1'){
     AccManager();
     }else{
     if(select == '2'){
     FinOrganizer();
     }else{
     if(select == '3'){
     Exit();
     }else{
     Menu();
     }
     }
     }

     }

     //This the main program list

void AccManager(){
     clrscr();

     cout <<"\t\t\tAccount Manager"<<endl;
     cout <<"\t\t\t=============="<<endl;

     cout <<"\n\n\t1) Make a Deposit"<<endl;
     cout <<"\n\t2) Make a Withdrawal"<<endl;
     cout <<"\n\t3) Check your Balance"<<endl;
     cout <<"\n\t4) Main Menu"<<endl;
     cout <<"\n\t5) Quit"<<endl;

     cout <<"\n\n\tEnter your selection: ";
     cin >>select;

     if(select == '1'){
     Deposit();
     }else{
     if(select == '2'){
     Withdrawal();
     }else{
     if(select == '3'){
     Balance();
     }else{
     if(select == '4'){
     Menu();
     }else{
     if(select == '5'){
     Menu();
     }else{
    AccManager();
     }
     }
     }
     }
     }
     }







void FinOrganizer(){
     clrscr();
     AM.Manager();

     Menu();
     }

void Exit(){
     clrscr();
     cout <<"\n\t\t\tProgram Comments"<<endl;
     cout <<"\t\t\t---------------"<<endl;

     cout <<"\n\n\tThis program was designed and writen by Fabian Glace,"<<endl;
     cout <<"\tA K A Vertualboy. Writing this program was fun for me because"<<endl;
     cout <<"\tthis is the first program that I personaly like since I began"<<endl;
     cout <<"\tprograming in C++, which is not that long a go. "<<endl;
     cout <<"\tI look farward to writing more programs that other people will"<<endl;
     cout <<"\tlike using in their work. Please e-mail me at"<<endl;
     cout <<"\tredhatmandrake@hotmail.com or visit www.technocode.scriptmania.com"<<endl;
     cout <<"\tfor more programs. Thank You."<<endl;

     getch();
     }


