class Account_Manager{

public:
		

		
	void Manager(){  //Manager is the main program function because it
                         //controls access to all the other functions.

		clrscr();

		char select;
		
		cout<<"\n\t\t\tFinance Organizer"<<endl;
		cout<<"\n\t\t\t=============="<<endl;
		
		cout<<"\n\n\tAdd Events(A)"<<endl;
		cout<<"\n\tVeiw Events(V)"<<endl;
                cout<<"\n\tDelete Events(D)"<<endl;
		cout<<"\n\tPost Events(P)"<<endl;
                cout<<"\n\tAbout Event Controller(I)"<<endl;
		cout<<"\n\tQuit(Q)"<<endl;
		
		cout<<"\n\n\tEnter selection: ";
		cin>>select;

                //This is a very straightforward if else statement.
                //To activate any of the proceeding functions you have to type
                //the corresponding letter eg (V --> View).

		if((select == 'V')||(select == 'v')){
			View();
		}else{
			if((select == 'A')||(select == 'a')){
			Add();
		}else{
				if((select == 'P')||(select == 'p')){
				Post();
		}else{
					if((select == 'Q')||(select == 'q')){

		}else{
                                                if((select == 'I')||(select == 'i')){
                                                About();
                }else{
                                                if((select == 'D')||(select == 'd')){
                                                Delete();
                }else{
                Manager();  //if a letter is typed that does not have a corresponding
                            //function the program loops back and refreshes the main
                            //menu.
	} } } } } } }

	int Add(){ //The Add function like the name describes adds new events
                   //to the program.

		clrscr(); //this function clears the screen everytime the add
                          //function is activated.

                //These are the variables that are used for entering information
                //like the name, amount, post and balance.
                char add;
		char Event_Name[20];
		int Event_Amount = 0;
		int Event_Post = 0;
		int Event_Balance = 0;

		cout<<"\n\t\aEvent Name: ";
		cin>>Event_Name; //Note add a name please don't leave any space between
                                 //the words (phone bills) -->(phone_bills).

		cout<<"\n\tEvent Amount: ";
		cin>>Event_Amount;
		
		Event_Balance = Event_Amount; //Event_Balance equals Event_Amount
                //because nothing has been posted yet, otherwise Event_Balance would
                //contain the balance from the amount posted.


		ofstream NameOut("Combine.cyl"); //This file was created in order to
                //hold the name of the file thats going to hold the account information
                //for instance the name of the Event you enter eg (phone bill)
                //will become the name of the file (phonebill.txt)
                //I don't know any other way to merge two separate text.
		NameOut<<Event_Name<<".txt"<<endl;
		NameOut.close();

		char File[20];

		ifstream NameIn("Combine.cyl");
		NameIn>>File;    //the text already being join together is retrieved
                                 //by the variable File as one word.
		NameIn.close();

		ofstream Out(File); //now it's being saved as a text file and the
                                    //following information is being entered.
		Out<<Event_Name<<endl;
		Out<<Event_Amount<<endl;
                Out<<Event_Post<<endl;
		Out<<Event_Balance<<endl;
		Out.close();

                cout<<"\n\tDo you want to add another(y/n): ";
                cin>>add;

                if((add == 'y')||(add == 'Y')){
                Add();
                }else{
                Manager();
                }
		
	}

	void Post(){    //The Post function post the amount you entered for the event
                        //and gives you the balance as and saves that information back
                        //in the same file.
                clrscr();
                int E_Num;
                int E_Amt;

		cout<<"\n\t\t\t\aPost Events"<<endl;
		cout<<"\t\t\t============"<<endl;

		cout<<"\n\n #"<<"\t"<<"Event Name"<<"\t"<<"Event Amount"<<"\t"<<"Event Posted"<<"\t"<<"Event Balance"<<endl;
		cout<<"======================================================================"<<endl;

                File_Content(); //this function is described in more detail below.
                //After the File_Content function is activated you're left
                //with the content of all the files you've entered and by
                //selecting an Event Number (1) and the amount you want to
                //post (300) you're telling the program to post 300 for file 1.
                cout<<"\n\tEnter an Event Number: ";
                cin>>E_Num;

                cout<<"\n\tEnter an Event Amount: ";
                cin>>E_Amt;


		char Event_Name[20];
		int Event_Amount;
		int Event_Post;
		int Event_Balance;
		int new_Balance;
                char post;
                char File_Name[20];

		struct ffblk f;
                char ff_name[26];
                int count = 0;
                //the findfirst() function finds all the txt files in the
                //corrent folder
		int done = findfirst("*.txt",&f,FA_HIDDEN);
                
        while(!done){  //this while function loops brining up all the text file
                       //in the folder until there is no more.

        count++;  //this is a counter that adds 1 every time a new file is found.

        ifstream In(f.ff_name); //f.ff_name becomes the file name that the information
                                //is coming out of.
        In>>Event_Name;
        In>>Event_Amount;
	In>>Event_Post;
        In>>Event_Balance;
        In.close();

        done = findnext(&f);

        if(count == E_Num){ //if the counted is equal to the number you first entered the loop will stop.

        ofstream Out(f.ff_name);
        Out<<Event_Name<<endl;
        Out<<Event_Amount<<endl;
        Out<<E_Amt<<endl;
        new_Balance = Event_Balance - E_Amt;
        Out<<new_Balance<<endl;
        Out.close();

        break;
        }else{
        continue;
        }

        }
        cout<<"\n\n\tThe amount <"<<E_Amt<<"> has been posted to Event Number <"<<count<<">."<<endl;
 	cout<<"\n\tDo you want to post another(y/n): ";
	cin>>post;

        if((post == 'y')||(post == 'Y')){
        Post();
        }else{
        Manager();
        }
	}




	void View(){  //you will be able to view all the events you have entered

		clrscr();
				
		cout<<"\n\t\t\t\aView Events"<<endl;
		cout<<"\t\t\t============"<<endl;

		cout<<"\n\n #"<<"\t"<<"Event Name"<<"\t"<<"Event Amount"<<"\t"<<"Event Posted"<<"\t"<<"Event Balance"<<endl;
		cout<<"======================================================================"<<endl;

		File_Content();
				
		cout<<"\n\tPress any key to go to the main menu...."<<endl;
		getchar();
		Manager();
		
	}

	private:

		void File_Content(){ //File_Content is what brings up all the files that is in the
                                     // current folder.
                                     //Everything here was explaned in the post function

		char Event_Name[20];
		int Event_Amount = 0;
		int Event_Post = 0;
		int Event_Balance = 0;
		
		struct ffblk f;
                char ff_name[26];
                int count = 0;
        
		int done = findfirst("*.txt",&f,FA_HIDDEN);
                
        while(!done){
        count++;
        ifstream In(f.ff_name);
        In>>Event_Name;
        In>>Event_Amount;
	In>>Event_Post;
        In>>Event_Balance;
        In.close();

	cout<<"\n "<<count<<setw(15)<<Event_Name<<setw(15)<<Event_Amount<<setw(15)<<Event_Post<<setw(15)<<Event_Balance<<endl;
        
        done = findnext(&f);

		} getchar();
	        }

        void About(){
        clrscr();
        char opt;

        cout<<"\n\t\t\t\aEvent Controller"<<endl;
        cout<<"\t\t\t================"<<endl;

        cout<<"\n\n\tHi, i'm Fabian Glace and I wrote this program"<<endl;
        cout<<"\tto help me keep track of my expences, whether it's my weekly"<<endl;
        cout<<"\tor monthly expences I never know how much money I spending."<<endl;
        cout<<"\tor what bill i'm in th process of paying. It's a very small "<<endl;
        cout<<"\tand handy program to use, not much right now but I just started"<<endl;
        cout<<"\tprogramming so give me some time. "<<endl;
        cout<<"\tAnyway thanks for using it and if I have more time in the coming"<<endl;
        cout<<"\tweeks i'll add some more features to it. So let me know how you"<<endl;
        cout<<"\tlike the program. I could be reach at redhatmandrake@hotmail.com"<<endl;
        cout<<"\tand for any more programs my website is at"<<endl;
        cout<<"\twww.technocode.scriptmania.com."<<endl;
        cout<<"\n\tThanks"<<endl;

        cout<<"\nDo you want to quit or return to main menu(q/m): ";
        cin>>opt;

        if(opt == 'q'){
        exit(1);
        }else{
        Manager();
        }


        }

       void Delete(){   //The Delete function is very important because after
                        //the full amount has been posted for an event you
                        //could delete to save space.

                int E_Num;

                clrscr();
		cout<<"\n\t\t\t\aDelete Events"<<endl;
		cout<<"\t\t\t============"<<endl;

		cout<<"\n\n #"<<"\t"<<"Event Name"<<"\t"<<"Event Amount"<<"\t"<<"Event Posted"<<"\t"<<"Event Balance"<<endl;
		cout<<"======================================================================"<<endl;

                File_Content();

                cout<<"\n\tEnter an Event Number: ";
                cin>>E_Num;


		char del;

		struct ffblk f;
                char ff_name[26];
                int count = 0;

		int done = findfirst("*.txt",&f,FA_HIDDEN);
                
        while(!done){

        count++;
        ifstream In(f.ff_name);
        In.close();

        done = findnext(&f);

        if(count == E_Num){

        remove(f.ff_name);

        break;
        }else{
        continue;
        }

        }

 	cout<<"\n\tDo you want to delete another(y/n): ";
	cin>>del;

        if((del == 'y')||(del == 'Y')){
        Delete();
        }else{
        Manager();
        }
	}
};			
				


		



