//TDglobals.cpp

#include <iostream.h>
#include "cTime_t.h"
#include "cDate_t.h"
#include "TDmanage.h"
#include "error.h"
//global functions:
//----------------


//cTime_t global functions:

ostream& operator << (ostream &out,const cTime_t &T) //operator << for class time function
{
	
	
	switch(cTime_t::format)
	{
	case 1:
		if(T.Seconds<10 && T.Minutes<10)
			out<<"The time is:  "<< T.Hours<<":0"<<T.Minutes<<":0"<<T.Seconds<<"."<<endl;
		else if (T.Seconds<10)
			out<<"The time is:  "<< T.Hours<<":"<<T.Minutes<<":0"<<T.Seconds<<"."<<endl;
		else if(T.Minutes<10)
			out<<"The time is:  "<< T.Hours<<":0"<<T.Minutes<<":"<<T.Seconds<<"."<<endl;
		else
			out<<"The time is:  "<< T.Hours<<":"<<T.Minutes<<":"<<T.Seconds<<"."<<endl;
		break;
	case 2:
		if(T.Hours<=12)
		{

			if(T.Seconds<10 && T.Minutes<10)
				out<<"The time is:  "<<T.Hours<<":0"<<T.Minutes<<":0"<<T.Seconds<< " AM."<<endl;
			else if(T.Seconds<10)
				out<<"The time is:  "<<T.Hours<<":"<<T.Minutes<<":0"<<T.Seconds<< " AM."<<endl;
			else if(T.Minutes<10)
			out<<"The time is:  "<< T.Hours<<":0"<<T.Minutes<<":"<<T.Seconds<<"AM."<<endl;
			else 
				out<<"The time is:  "<<T.Hours<<":"<<T.Minutes<<":"<<T.Seconds<< " AM."<<endl;
		}
		else
		{		
			if(T.Seconds<10 && T.Minutes<10)
				out<<"The time is:  "<<T.Hours-12<<":0"<<T.Minutes<<":0"<<T.Seconds<< " PM."<<endl;
			else if(T.Seconds<10)
				out<<"The time is:  "<<T.Hours-12<<":"<<T.Minutes<<":0"<<T.Seconds<< " PM."<<endl;
			else if(T.Minutes<10)
				out<<"The time is:  "<< T.Hours<<":0"<<T.Minutes<<":"<<T.Seconds<<"PM."<<endl;
			else
				out<<"The time is:  "<<T.Hours-12<<":"<<T.Minutes<<":"<<T.Seconds<< " PM."<<endl;
		}
		break;
	default:
		out<<"The format is not ok"<<endl;
	}
	return out;
}
istream& operator >> (istream &in, cTime_t &T)//operator >> for class time function
{
	cout<<"Enter hour:";
	in>>T.Hours;
	cout<<"Enter Minutes:";
	in>>T.Minutes;
	cout<<"Enter Seconds:";
	in>>T.Seconds;
	return in;
}

//cDate_t global functions:

ostream& operator << (ostream &out,const cDate_t &D)//operator << for class date function
{
	
	
	if(D.Error)
	{
		Error2();
		return out;
	}
	switch(cDate_t::format)
	{
	case 1: //European
		out<<"The date is:  "<< D.Day<<"/"<<D.Month<<"/"<<D.Year<<"."<<endl;
		break;
	case 2: //American
		out<<"The date is:  "<<D.Month<<"/"<<D.Day<<"/"<<D.Year<< "."<<endl;
		break;
	case 3: //with string instead of month
		out<<"The date is:  "<<D.Day<<"/"<<D.Mon[D.Month-1]<<"/"<<D.Year<< "."<<endl;
		break;
	default:
		out<<"The format is not ok"<<endl;
	}
	return out;
}
istream& operator >> (istream &in, cDate_t &D)//operator >> for class date function
{
	cout<<"Enter year:";
	in>>D.Year;
	cout<<"Enter month (1-12):";
	in>>D.Month;
	cout<<"Enter day (1-31):";
	in>>D.Day;
	if (D.Year<1900)
	{
		Error1();
		D.Error=true;
	}
	else
		D.Error=false;
	return in;
}

ostream& operator << (ostream &out,const cTDmanage &M)//operator << for class cTDmanage function
{
	out<<M.D<<" and "<<M.T<<endl;
	return out;
}
istream& operator >> (istream &in, cTDmanage &M)//operator >> for class cTDmanage function
{
	in>>M.D;
	in>>M.T;
	return in;
}
