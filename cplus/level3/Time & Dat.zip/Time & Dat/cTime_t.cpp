//cTime_t.cpp
//implementation of cTime_t

#include "cTime_t.h"

int cTime_t::format=1;
int cTime_t::FlagMoreDay=0; // default values for static data members
int cTime_t::FlagLessDay=0;

//------------------------------------
cTime_t::cTime_t() //empty c'tor
{
	time_date=time(0);
	CurrentTime=localtime(&time_date);
	Seconds=CurrentTime->tm_sec;
	Minutes=CurrentTime->tm_min;
	Hours=CurrentTime->tm_hour;
}
//------------------------------------

cTime_t::cTime_t(const cTime_t &T) //copy c'tor
{
	Seconds=T.Seconds;
	Minutes=T.Minutes;
	Hours=T.Hours;
}
//------------------------------------

const cTime_t& cTime_t::operator = (const cTime_t& T) //operator = function
{
	
	Seconds=T.Seconds;
	Minutes=T.Minutes; // copy relevent fields
	Hours=T.Hours;
	return *this;
}
//------------------------------------
void cTime_t::print() const //print function
{
	switch(format)
	{
	case 1:
		if(Seconds<10 && Minutes<10)
			cout<<"The time is:  "<< Hours<<":0"<<Minutes<<":0"<<Seconds<<"."<<endl;
		else if(Seconds<10)
			cout<<"The time is:  "<< Hours<<":"<<Minutes<<":0"<<Seconds<<"."<<endl;
		else if(Minutes<10)
			cout<<"The time is:  "<< Hours<<":0"<<Minutes<<":"<<Seconds<<"."<<endl;
		else
			cout<<"The time is:  "<< Hours<<":"<<Minutes<<":"<<Seconds<<"."<<endl;
		break;
	case 2:
		if(Hours<=12)
		{
			if(Seconds<10 && Minutes<10)
				cout<<"The time is:  "<<Hours<<":0"<<Minutes<<":0"<<Seconds<< " AM."<<endl;
			else if(Minutes<10)
				cout<<"The time is:  "<<Hours<<":0"<<Minutes<<":"<<Seconds<< " AM."<<endl;
			else if(Seconds<10)
				cout<<"The time is:  "<<Hours<<":"<<Minutes<<":0"<<Seconds<< " AM."<<endl;
			else 
				cout<<"The time is:  "<<Hours<<":"<<Minutes<<":"<<Seconds<< " AM."<<endl;
		}
		else
		{
			if (Seconds<10 && Minutes<10)
				cout<<"The time is:  "<<Hours-12<<":0"<<Minutes<<":0"<<Seconds<< " PM."<<endl;
			else if (Minutes<10)
				cout<<"The time is:  "<<Hours-12<<":0"<<Minutes<<":"<<Seconds<< " PM."<<endl;
			else if (Seconds<10)
				cout<<"The time is:  "<<Hours-12<<":"<<Minutes<<":0"<<Seconds<< " PM."<<endl;
			else
				cout<<"The time is:  "<<Hours-12<<":"<<Minutes<<":"<<Seconds<< " PM."<<endl;
		}
		break;
	default:
		cout<<"The format is not ok"<<endl; //error (if format value wasn't one of the above
	}
}
//------------------------------------
bool cTime_t::operator < (const cTime_t& T)const //operator < function
{
	if (Hours<T.Hours)
		return true;
	if(Hours==T.Hours)
	{
		if(Minutes<T.Minutes)
			return true;
		if(Minutes==T.Minutes)
			return (Seconds<T.Seconds);
	}
	return false;
}
//------------------------------------
bool cTime_t::operator <= (const cTime_t &T)const //operator <= function
{
	if (Hours<T.Hours)
		return true;
	if(Hours==T.Hours)
	{
		if(Minutes<T.Minutes)
			return true;
		if(Minutes==T.Minutes)
			return (Seconds<=T.Seconds);
	}
	return false;
}
//------------------------------------
bool cTime_t::operator > (const cTime_t& T)const //operator > function
{
	if (Hours>T.Hours)
		return true;
	if(Hours==T.Hours)
	{
		if(Minutes>T.Minutes)
			return true;
		if(Minutes==T.Minutes)
			return (Seconds>T.Seconds);
	}
	return false;
}
//------------------------------------	
bool cTime_t::operator >= (const cTime_t& T)const //operator >= function
{
	if (Hours>T.Hours)
		return true;
	if(Hours==T.Hours)
	{
		if(Minutes>T.Minutes)
			return true;
		if(Minutes==T.Minutes)
			return (Seconds>=T.Seconds);
	}
	return false;
}
//------------------------------------
bool cTime_t::operator == (const cTime_t &T)const //operator == function
{
	return ( (Hours==T.Hours) && (Minutes==T.Minutes) && (Seconds==T.Seconds) );
}
//------------------------------------
bool cTime_t::operator != (const cTime_t &T)const//operator != function
{
	return !( (Hours==T.Hours) && (Minutes==T.Minutes) && (Seconds==T.Seconds) );
}
//------------------------------------
const cTime_t cTime_t::operator + (const cTime_t &T) const //operator + function
{
	int HourTemp,MinuteTemp,SecondTemp;//define 3 temp variables to get time data
	SecondTemp=Seconds+T.Seconds;
	if(SecondTemp>=60)//more thrn 1 minute
	{
		SecondTemp-=60;
		MinuteTemp=Minutes+T.Minutes+1;//so add to minute
	}
	else
		MinuteTemp=Minutes+T.Minutes;
	if(MinuteTemp>=60)//more then 1 hour
	{
		MinuteTemp-=60;
		HourTemp=Hours+T.Hours+1;//add to hour
	}
	else
		HourTemp=Hours+T.Hours;
	if(HourTemp>=24)
	{
		FlagMoreDay=1; //to add day to date class
		HourTemp-=24;
	}
	
	return (cTime_t (HourTemp,MinuteTemp,SecondTemp) ); //return local time class 
}
//------------------------------------
const cTime_t cTime_t::operator - (const cTime_t &T) const //operaor - function
{
	int HourTemp,MinuteTemp,SecondTemp;//define 3 temp variables to get time data
	HourTemp = Hours-T.Hours;
	if(HourTemp<0)//T class hour was bigger then THIS class
	{
		FlagLessDay=1; //to cut 1 day form date class
		HourTemp+=24;// add 24 hours to previous day
	}
	MinuteTemp=Minutes-T.Minutes;
	if(MinuteTemp<0)//same for minutes
	{
		MinuteTemp+=60;
		--HourTemp;
	}
	SecondTemp=Seconds-T.Seconds;
	if(SecondTemp<0)//same for seconds
	{
		SecondTemp+=60;
		--MinuteTemp;
	}
	return ( cTime_t ( HourTemp,MinuteTemp,SecondTemp) );//return local class 
}
//------------------------------------

void cTime_t::operator ++ () //operator ++ function
{
	if ( (Seconds==59) && (Minutes==59) && (Hours==23) ) // end of a day
	{
		FlagMoreDay=1;//to add day to day class
		Seconds=0;
		Minutes=0;
		Hours=0;
		
	}
	else if( (Seconds==59) && (Minutes==59) )//end of hour
	{
		Seconds=0;
		Minutes=0;
		++Hours;
	}
	else if( Seconds==59 )//end of minute
	{
		Seconds=0;
		++Minutes;
	}
	else
		++Seconds;

}

//------------------------------------
void cTime_t::operator -- () //operator -- function
{
	if ( (Seconds==0) && (Minutes==0) && (Hours==0) )//start of day
	{
		FlagLessDay=1;//to substruct 1 day from day class
		Seconds=59;
		Minutes=59;
		Hours=23;
		
	}
	else if( (Seconds==0) && (Minutes==0) )//start of hour
	{
		Seconds=59;
		Minutes=59;
		--Hours;
	}
	else if( Seconds==0 )//start of minute
	{
		Seconds=59;
		--Minutes;
	}
	else
		--Seconds;

}



			
				





