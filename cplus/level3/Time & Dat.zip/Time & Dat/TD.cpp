/******************************
 *     TIME & DATE            *
 * written : Amit Friedmann   *
 * amitf@hotmail.co.il        *
 * This code can be used      *
 * freely, and can be changed *
 *							  *
 ******************************/

//TD.cpp

#include "error.h"
#include "TDmanage.h"

#include <iostream.h>
#include <string.h>
#include <stdio.h>




//main:

void main()
{
	
	char DayName[10];
	char MonthName[10];
	bool Test;
	int c;
	printf("Time Date - Exercise 1\n");
	printf("======================\n");
	// 1
	printf("** making default object (M1), get current computer time **\n");
	cTDmanage M1;
	M1.print();
	putchar('\n');
	// 2
	printf("** get current day in default object **\n");
	strcpy(DayName,M1.GetDDayOfWeekName());
	printf("%s\n",DayName);
	putchar('\n');
	//3
	printf("** initialize a new object (M2) with date and time data and print it **\n");
	cTDmanage M2(3,7,47,1904,1,27);
	M2.print();
	putchar('\n');
	//4
	printf("** making a new object (M3) that will get the data of M1+M2 and print it **\n");
	cTDmanage M3=M1+M2;
	M3.print();
	putchar('\n');
	//5
	printf("** printing M3 in 2 others formats **\n");
	M3.ChangeDateFormat();
	M3.print();
	M3.ChangeDateFormat();
	M3.print();
	putchar('\n');
	printf("Press a Enter to continue...");
	c=getchar();
	printf("------------------------------------------------------------------------\n");
	//6
	printf("** making 2 'good' object (M4,M5) **\n");
	cTDmanage M4 (19,0,0,2000,2,1);
	M4.print();
	cTDmanage M5(18,0,0,1999,1,2);
    M5.print();
	putchar('\n');
	//7
	printf("** make new object (M6) and try to do M4-M5 and to print it **\n");
	cTDmanage M6=M4-M5;
	M6.print();
	putchar('\n');
	//8
	printf("** give M6 the data of M4 with operator = and print it (make him 'good') **\n");
	M6=M4;
	M6.print();
	putchar('\n');
	//9
	printf(" ** make object (M7) from classes time&date and print before/after using ++ **\n");
	cTDmanage M7 (cDate_t(1950,12,31),cTime_t(15,55,38));
	M7.print();
	++M7;
	M7.print();
	putchar('\n');
	printf("Press a Enter to continue...");
	c=getchar();
	printf("------------------------------------------------------------------------\n");
	//10
	printf(" ** print name of month of M7 **\n");
	strcpy(MonthName,M7.GetDNameOfMonth());
	printf("%s\n",MonthName);
	putchar('\n');
	//11
	printf("** check if M7 (1/1/1951,15:55:39) > M5 (2/1/1999,18:00:00) **\n");
	Test=M7>M5;
	if(Test)
		printf("M7 is greater\n");
	else
		printf("M5 is greater\n");
	putchar('\n');
	//12
	printf("** make new object M8 equal to M7 and check it with operator == **\n");
	cTDmanage M8(15,55,39,1951,1,1);
	Test=(M7==M8);
	if(Test)
		printf("M7 and M8 are equal\n");
	else
		printf("M7 and M8 are not equal\n");
	
	
	
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis are 12 examples of the program. More explanation in the note.txt file\n");


	
	




	
}
