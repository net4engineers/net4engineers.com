//cDate_t.h

#include <iostream.h>
#include <time.h>


#ifndef cDate_t_h
#define cDate_t_h

#define N 3

class cDate_t
{
	enum Days {Saturday,Sunday,Monday,Tuesday,Wensday,Thursday,Friday };
	enum Months {None,January,February,Mars,April,May,June,July,August,September,October,November,December };
	
	
	static int format;
	static char Mon[][10];
	static char DDays[][10];
	int Day;
	int Month;
	int Year;
	struct tm *CurrentTime;
	time_t time_date;
	bool Error;
public: 
	
	cDate_t();
	cDate_t(const cDate_t &D);
	cDate_t(int year,int month,int day);
	
	
	~cDate_t(){}

	const cDate_t& operator = (const cDate_t& D);

	inline void SetDay (int day) {Day=day;}
	inline void SetMon (int mon) {Month=mon;}
	inline void SetYear (int year) {Year=year;}

	void print() const;

	inline int GetDayOfMonth () const {return Day;}
	inline int GetMonth () const {return Month;}
	inline int GetYear () const {return Year;}
	int GetDayOfYear(int year,int month,int day);
	int GetDaysInMonth(int month,int year);
	int GetDayOfWeek();
	bool IsLeapYear(int year);
	char* GetDayOfWeekName();
	char* GetNameOfMonth();
	int RetriveDay(int Days,int year);
	int RetriveMonth(int Days,int year);

	bool operator < (const cDate_t& D)const;
	bool operator <= (const cDate_t& D)const;
	bool operator > (const cDate_t& D)const;
	bool operator >= (const cDate_t& D)const;
	bool operator == (const cDate_t& D)const;
	bool operator != (const cDate_t& D)const;

	const cDate_t operator + (const cDate_t& D) ;
	const cDate_t operator - (const cDate_t& D) ;
	void operator ++ ();
	void operator -- ();

    static void cDate_t::ChangeFormat() //implementation of static function must be in header
{
	switch(format)
	{
	case 1:
		format=2;
		break;
	case 2:
		format=3;
		break;
	case 3:
		format=1;
	}
}
	
	friend ostream& operator << (ostream &out,const cDate_t &D) ;
    friend istream& operator >> (istream &in, cDate_t &D) ;

	void SetError() {Error=false;}
	friend class cTDmanage;

};

#endif