//error.cpp
//implementation of error.h 

#include "error.h"

void Error1() // used for setting class with c'tor or operator =
{
	cout<<"You tried to set a year that is less then 1900, which is illegal"<<endl;
}

void Error2() //used for trying to print an error class
{
	cout<<"There are error/s in your date (year less then 1900). Can't print date."<<endl;
}

void Error3() //used for operator +
{
	cout<<"There are error/s in your date (year less then 1900). Can't use + of date."<<endl;
}

void Error4()  //used for operaor - 
{
	cout<<"There are error/s in your date (year less then 1900). Can't use - of date."<<endl;
}

void Error5()  //used for operator - and GetDayOfYear function
{
	cout<<"There are error/s in your date (year less then 1900). Can't get day of year."<<endl;
}