//TDmanage.h

#include <iostream.h>
#include <time.h>

#include "cDate_t.h"
#include "ctime_t.h"

#ifndef TDmanage_h
#define TDmanage_h

class cTDmanage
{
	
	cTime_t T;
	cDate_t D;
public:
	cTDmanage (){}
	cTDmanage (const cDate_t &DD): D(DD) {}
	cTDmanage (const cTime_t &TT): T(TT) {}
	cTDmanage (const cDate_t &DD,const cTime_t &TT): D(DD),T(TT) {}
	cTDmanage (int hour,int minute,int second):T(hour,minute,second) {}
	cTDmanage (int hour,int minute,int second,int year,int month,int day):T(hour,minute,second),D(year,month,day) {}
	
	void operator = (const cTDmanage& M) {T=M.T ; D=M.D ;}
	
	//option to put all get and set function of date and time class 

	int GetDDayOfWeek() { return D.GetDayOfWeek(); }
	bool IsDLeapYear (int year) { return D.IsLeapYear(year); }
	char* GetDDayOfWeekName() { return D.GetDayOfWeekName(); }
	char* GetDNameOfMonth() { return D.GetNameOfMonth(); }
	int RetriveDDay(int Days,int year) { return D.RetriveDay(Days,year); }
	int RetriveDMonth(int Days,int year) { return D.RetriveMonth(Days,year); }
	
	//if you want to do operations only on 1 of the classes
	const cTime_t& GetTimeObj () { return T; } 
	const cDate_t& GetDateObj () { return D; }
	
	void print() const;
	//operator:
	bool operator <  (const cTDmanage& M)const {return ( (T<M.T ) && (D<M.D) );  }
	bool operator <= (const cTDmanage& M)const {return ( (T<=M.T) && (D<=M.D) ); }
	bool operator >  (const cTDmanage& M)const {return ( (T>M.T ) && (D>M.D) );  }
	bool operator >= (const cTDmanage& M)const {return ( (T>=M.T) && (D>=M.D) ); }
	bool operator == (const cTDmanage& M)const {return ( (T==M.T) && (D==M.D) ); }
	bool operator != (const cTDmanage& M)const {return ( (T!=M.T) && (D!=M.D) ); }
	
	const cTDmanage operator + (const cTDmanage& M) ;
	const cTDmanage operator - (const cTDmanage& M) ;
	//using Date and Time ++ operator:
	void operator ++ () { AddDay() ; AddSecond() ; }
	void AddDay() { ++D; }
	void AddSecond() { ++T; }

	void ChangeDateFormat() { D.ChangeFormat(); }
	void ChangeTimeFormat() { T.ChangeFormat(); }

	
	friend ostream& operator << (ostream &out,const cTDmanage &M) ;
    friend istream& operator >> (istream &in, cTDmanage &M) ;
};

#endif



	
	

	

