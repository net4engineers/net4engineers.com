//cDate_t.cpp 
//implementation of cDate_t.h

#include "cDate_t.h"
#include "error.h"

int cDate_t::format=1;
char cDate_t::Mon[][10] = {"Janaury","February","Mars","April","May","Juny","July","August","September","October","November","December" };
char cDate_t::DDays[][10] = {"Saturday","Sunday","Monday","Tuesday","Wensday","Thursday","Friday" };
//------------------------------------
cDate_t::cDate_t() //empty c'tor
{
	SetError();
	time_date=time(0);
	CurrentTime=localtime(&time_date); //get data from computer about today date
	Day=CurrentTime->tm_mday;
	Month=CurrentTime->tm_mon+1;
	Year=CurrentTime->tm_year+1900;
}
//------------------------------------

cDate_t::cDate_t(int year,int month,int day):Year(year),Month(month),Day(day) //c'tor
{
	SetError();
	if (Year<1900) //bad data 
	{
		Error1();
		Error=true;
	}
}
//------------------------------------
cDate_t::cDate_t(const cDate_t &D) //copy c'tor
{
	SetError();
	Day=D.Day;
	Month=D.Month;
	Year=D.Year;
	if (Year<1900)//bad data
	{
		Error1();
		Error=true;
	}
}

//------------------------------------
const cDate_t& cDate_t::operator = (const cDate_t& D) //operator = function
//get same data object and copy to THIS class all fields
{
	Day=D.Day;
	Month=D.Month;
	Year=D.Year;
	if (Year<1900)//bad data from the other object
	{
		Error1();
		Error=true;
	}
	else
		SetError();
	return *this;
}
//------------------------------------
void cDate_t::print() const //print function
//prints all relevent date fields
{
	
	char str[N]; //string to store 3 first letters of month
	for(int i=0;i<N;++i)
		str[i]=Mon[Month-1][i];//copt from static member
	str[i]='\0';
	if(Error)//check for bad data
	{
		Error2();
		return;
	}

	switch(format) //kind of printing
	{
	case 1: //European
		cout<<"The date is:  "<< Day<<"/"<<Month<<"/"<<Year<<"."<<endl;
		break;
	case 2: //American
		cout<<"The date is:  "<<Month<<"/"<<Day<<"/"<<Year<< "."<<endl;
		break;
	case 3: //with string instead of month
		cout<<"The date is:  "<<Day<<"/"<<str<<"/"<<Year<< "."<<endl;
		break;
	default:
		cout<<"The format is not ok"<<endl;
	}
}
//------------------------------------
bool cDate_t::operator < (const cDate_t& D)const // operator < function
// return true if THIS object is < then the second
{
	if (Year<D.Year)
		return true;
	if(Year==D.Year)
	{
		if(Month<D.Month)
			return true;
		if(Month==D.Month)
			return (Day<D.Day);
	}
	return false;
}
//------------------------------------
bool cDate_t::operator <= (const cDate_t &D)const // operator <= function
// return true if THIS object is <= then the second
{
	if (Year<D.Year)
		return true;
	if(Year==D.Year)
	{
		if(Month<D.Month)
			return true;
		if(Month==D.Month)
			return (Day<=D.Day);
	}
	return false;
}
//------------------------------------
bool cDate_t::operator > (const cDate_t& D)const //operator > function
// return true if THIS object is > then the second
{
	if (Year>D.Year)
		return true;
	if(Year==D.Year)
	{
		if(Month>D.Month)
			return true;
		if(Month==D.Month)
			return (Day>D.Day);
	}
	return false;
}
//------------------------------------	
bool cDate_t::operator >= (const cDate_t &D)const //operator >=
// return true if THIS object is >= then the second
{
	if (Year>D.Year)
		return true;
	if(Year==D.Year)
	{
		if(Month>D.Month)
			return true;
		if(Month==D.Month)
			return (Day>=D.Day);
	}
	return false;
}
//------------------------------------
bool cDate_t::operator == (const cDate_t &D)const//operator == function
//return true if THIS object and the second one are equal in all their date data member 
{
	return ( (Year==D.Year) && (Month==D.Month) && (Day==D.Day) );
}
//------------------------------------
bool cDate_t::operator != (const cDate_t &D)const//operator != function
//return true if THIS object and the second one are not equal in all their date data member 
{
	return !( (Year==D.Year) && (Month==D.Month) && (Day==D.Day) );
}
//------------------------------------
const cDate_t cDate_t::operator + (const cDate_t &D)//operator + function  
{
	int YearTemp,MonthTemp,DayTemp,NewDays; //variables to store to new date object 
	if(Error || D.Error) // if no less then 1 object have orror data
	{
		Error3(); // print orror messege
		return (cDate_t (-1,-1,-1) ); //return error class
	}
	YearTemp=Year+D.Year; //get the sum of years
	NewDays=GetDayOfYear(Year,Month,Day) + GetDayOfYear(D.Year,D.Month,D.Day); //get sum of days
	if(NewDays > ((IsLeapYear(YearTemp))? 366 : 365)) //if the sum is more thrn in 1 year 
	{
		NewDays=NewDays - ((IsLeapYear(YearTemp))? 366 : 365);//cut 1 year days
		YearTemp+=1;//and add a year
	}
	DayTemp=RetriveDay(NewDays,YearTemp); //retrive the current day in the specific month
	MonthTemp=RetriveMonth(NewDays,YearTemp);//same with month
	
	return (cDate_t (YearTemp,MonthTemp,DayTemp) );// return a local object , created only for return  
}
//------------------------------------
const cDate_t cDate_t::operator - (const cDate_t &D) //operator - function
{
	int YearTemp,MonthTemp,DayTemp,NewDays,Temp1,Temp2; //variables to store to new date object 
	if(Error || D.Error)// if no less then 1 object have orror data
	{
		Error4();// print orror messege
		return (cDate_t (-1,-1,-1) ); //return error class
	}
	YearTemp=Year-D.Year;//substraction of THIS and second year
	if(YearTemp<1900) // error 
	{
		Error1();//print error messege
		return (cDate_t (-1,-1,-1) ); //return error class
	}
	Temp1=GetDayOfYear(Year,Month,Day); // get days of year of THIS object
	if(Temp1<0) //error
	{
		Error5();//print error messege
		return (cDate_t (-1,-1,-1) );//return error class
	}
	Temp2=GetDayOfYear(D.Year,D.Month,D.Day);// get days of year of second object
	if(Temp2<0)//error
	{
		Error5();//print error messege
		return (cDate_t (-1,-1,-1) );//return error class
	}
	NewDays= Temp1 - Temp2; //if the data ok get their substraction
	if(NewDays<0) // the substraction is less then zero
	{
		NewDays = NewDays + ((IsLeapYear(YearTemp))? 366 : 365); // set days for previous year
		YearTemp-=1; //sub 1 year
	}
	DayTemp=RetriveDay(NewDays,YearTemp); //retrive the current day in the specific month
	MonthTemp=RetriveMonth(NewDays,YearTemp);//same with month
	return (cDate_t (YearTemp,MonthTemp,DayTemp) );//return local class  
}
//------------------------------------

int cDate_t::GetDayOfYear(int year,int month,int day) //get day of year function
{
	int NumOfDay=0; //variable to store number of days util the current month
	int DaysIn1Month=0; // get days in each month to add to NumOfDay
	while(month!=1 && DaysIn1Month!=-1) //loop for all the month except the current one
	{
		DaysIn1Month=GetDaysInMonth(month,year); //for checking
		NumOfDay+=DaysIn1Month; 
		month--;
	}
	if(DaysIn1Month==-1)
		return -1; //error
	else
	return NumOfDay+day; //return number of days until this month + days from this month 
}
//------------------------------------
int cDate_t::GetDaysInMonth(int month,int year) // get days in month function
{
	switch(month)
	{
		case January:case Mars: case May: case July: case August: case October: case December:
			return 31;
		case April: case June: case September: case November:
			return 30;
		case February:
			if(IsLeapYear(year))
				return 29;
			else
				return 28;
	}
	return -1; //error (should never visit this line!)
}
//------------------------------------
int cDate_t::GetDayOfWeek() //starting point : 1/1/1900 was Monday (Saturday==0,Sunday==1,...)
{
	int weekday=2 ; //in 1/1/1900
	for(int TheYear=1900;TheYear<Year;++TheYear) //loop to know the day in 1/1/this year
	{
		if(IsLeapYear(TheYear))
			weekday=(weekday+366)%7; 
		else
			weekday=(weekday+365)%7;
	}
	//until here we found the correct day in 1/1/this year
	for(int TheMonth=1;TheMonth<Month;++TheMonth)
		weekday=(weekday+GetDaysInMonth(TheMonth,Year))%7;
	//until here we found the correct day in 1/this month
	return (weekday+Day)%7-1; //the correct day in THIS day...
}
//------------------------------------

bool cDate_t::IsLeapYear(int year) // is leap year function
{
	return (!(year%4)) && (year%100) || (!(year%400));
}

//------------------------------------
char* cDate_t::GetDayOfWeekName() // get day of week function
{
	 
	int Weekday=GetDayOfWeek();
	return DDays[Weekday]; // use static DDays to identify the day
	
	
}
//------------------------------------
char* cDate_t::GetNameOfMonth() // get name of month function
{
	return Mon[Month-1]; // use static Mon to identify the month
}
//------------------------------------
int cDate_t::RetriveDay(int Days,int year) // retrive day function 
// do the oppiste thing - find the day in a month when know the days from the start of year
{
	int day=Days; //varable to store days
	int leap=(IsLeapYear(year)); // know if the current year is leaped
	int M = (leap)? 29 : 28;
	for(int mon=1;mon<=12;++mon) //loop of month
	{
		if ( (day<=31 && (mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12))
			|| (day<=30 && (mon==4 || mon==6 || mon==9 || mon==11)) || (day<=M && mon==2) )
			return day;
		else
			day-=GetDaysInMonth(mon,year);
	}
	return -1; // if there was an error
}
//------------------------------------
int cDate_t::RetriveMonth(int Days,int year) // retrive month function 
//same as retrive day just returning the month
{
	int day=Days;
	int leap=(IsLeapYear(year));
	int M = (leap)? 29 : 28;
	for(int mon=1;mon<=12;++mon) //loop of month
	{
		if( (day<=31 && (mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12 ))
			|| (day<=30 && (mon==4 || mon==6 || mon==9 || mon==11)) || (day<=M && mon==2) )
			return mon;
		else
			day-=GetDaysInMonth(mon,year);
	}
	return -1;
}
//------------------------------------

void cDate_t::operator ++ () // operator ++ function
{
	if( (Day==GetDaysInMonth(Month,Year)) && (Month==12) ) // if reached the end of the year
	{
		Day=1;
		Month=1;
		++Year;
	}
	else if( (Day==GetDaysInMonth(Month,Year)) ) // if reached the end of the month (but not year)
	{
		Day=1;
		++Month;
	}
	else
		++Day; // add 1 day
}

//------------------------------------

void cDate_t::operator -- () //operator -- function
{
	if( (Day==1) && (Month==1) ) // start of year
	{
		Day=31; //in december there r always 31 days
		Month=12;
		--Year;
	}
	else if( Day==1 ) //start of month (but not year)
	{
		--Month;
		Day=GetDaysInMonth(Month,Year);
		
	}
	else
		--Day;
}


	













			
		

