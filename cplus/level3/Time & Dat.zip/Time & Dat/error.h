//error.h

#include <iostream.h>
#ifndef _error_h
#define _error_h

void Error1();
void Error2();
void Error3();
void Error4();
void Error5();

#endif