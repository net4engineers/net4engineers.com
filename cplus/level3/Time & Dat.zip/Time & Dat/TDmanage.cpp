//TDmanage.cpp

#include "TDmanage.h"

void cTDmanage::print() const
{
	D.print();
	T.print();
}

const cTDmanage cTDmanage::operator + (const cTDmanage& M)
{
	cTime_t TT = T + M.T;
	cDate_t DD = D + M.D;
	if(cTime_t::FlagMoreDay==1)
		++DD.Day;
	cTime_t::FlagMoreDay=0;

	return ( cTDmanage ( DD,TT) );
}
const cTDmanage cTDmanage::operator - (const cTDmanage& M)
{
	cTime_t TT = T - M.T;
	cDate_t DD = D - M.D;
	if(cTime_t::FlagLessDay==1)
		--DD.Day;
	cTime_t::FlagLessDay=0;

	return ( cTDmanage ( DD,TT) );
}


	


