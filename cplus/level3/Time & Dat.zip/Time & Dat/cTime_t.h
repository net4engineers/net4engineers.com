//cTime_t.h

#include <iostream.h>
#include <time.h>

#ifndef cTime_t_h
#define cTime_t_h

class cTime_t
{
	static int FlagMoreDay;
	static int FlagLessDay;
	static int format;
	int Seconds;
	int Minutes;
	int Hours;
	struct tm *CurrentTime;
	time_t time_date;
public:
	
	
	cTime_t();
	cTime_t(const cTime_t &T);
	cTime_t(int hour,int min=0,int sec=0):Seconds(sec),Minutes(min),Hours(hour) {};

	~cTime_t(){};

	const cTime_t& operator = (const cTime_t& T);

	inline void SetSec (int sec) {Seconds=sec;}
	inline void SetMin (int min) {Minutes=min;}
	inline void SetHour (int hour) {Hours=hour;}

	void print() const;

	inline int GetSec () const {return Seconds;}
	inline int GetMin () const {return Minutes;}
	inline int GetHour () const {return Hours;}

	bool operator < (const cTime_t& T)const;
	bool operator <= (const cTime_t& T)const;
	bool operator > (const cTime_t& T)const;
	bool operator >= (const cTime_t& T)const;
	bool operator == (const cTime_t& T)const;
	bool operator != (const cTime_t& T)const;

	const cTime_t operator + (const cTime_t& T) const;
	const cTime_t operator - (const cTime_t& T) const;
	void operator ++ ();
	void operator -- (); 

    static void ChangeFormat() { format = (format==1)? 2 : 1 ; } //format can be only 1 or 2
	
	friend ostream& operator << (ostream &out,const cTime_t &T) ;
    friend istream& operator >> (istream &in, cTime_t &T) ;

	friend class cTDmanage;

};

#endif





