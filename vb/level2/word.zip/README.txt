SIMPLE WORD PROCESSOR  
developed by kishore@iqresearch.net
