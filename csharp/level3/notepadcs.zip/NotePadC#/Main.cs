//By Ajit Mungale --> ajit_mungale@hotmail.com

namespace NotePad
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;
    using System.Data;
    using System.IO;	//For file handling
	using System.Drawing.Printing; //For Printing
	using Microsoft.Win32 ;
	

    public class Form1 : System.WinForms.Form
    {
        private System.ComponentModel.Container components;
		private System.WinForms.MenuItem mnuAbout;
		private System.WinForms.MenuItem mnuSetBackCol;
		private System.WinForms.MenuItem menuItem7;
		private System.WinForms.MenuItem menuItem6;
		private System.WinForms.MenuItem mnuSetFontColor;
		private System.WinForms.ColorDialog colorDialog1;
		private System.WinForms.FontDialog fontDialog1;
		//private System.WinForms.MenuItem mnuFontColor;
		private System.WinForms.MenuItem mnuSetFont;
		private System.WinForms.MenuItem mnuWordWrap;
		private System.WinForms.MenuItem MnuTimeDate;
		private System.WinForms.MenuItem mnuSelectAll;
		private System.WinForms.MenuItem menuItem5;
		private System.WinForms.MenuItem mnuDelete;
		private System.WinForms.MenuItem mnuCut;
		private System.WinForms.MenuItem menuItem2;
		private System.WinForms.MenuItem mnuUndo;
		private System.WinForms.PageSetupDialog pageSetupDialog1;
		private System.WinForms.PrintDialog printDialog1;
		private System.WinForms.SaveFileDialog saveFileDialog1;
		private System.WinForms.OpenFileDialog openFileDialog1;
		private System.WinForms.MenuItem mnuExit;
		private System.WinForms.MenuItem menuItem12;
		private System.WinForms.MenuItem mnuPrint;
		private System.WinForms.MenuItem mnuPageSetUp;
		private System.WinForms.MenuItem menuItem9;
		private System.WinForms.TextBox textBox1;
		private System.WinForms.MenuItem mnuPaste;
		private System.WinForms.MenuItem mnuCopy;
		private System.WinForms.MenuItem mnuEdit;
		private System.WinForms.MenuItem mnuSaveAs;
		private System.WinForms.MenuItem mnuSave;
		private System.WinForms.MenuItem mnuOpen;
		private System.WinForms.MenuItem mnuNew;
		private System.WinForms.MenuItem mnuFile;
		private System.WinForms.MainMenu mainMenu1;

		private bool blnSaveChkFlag ;

        public Form1()
        {
            InitializeComponent();
		
			//
			textBox1.Width =this.Width ;
			textBox1.Height =this.Height ;
			GetSettings();	//Get Default Setting
        }

        
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

       
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.mnuAbout = new System.WinForms.MenuItem ();
			this.pageSetupDialog1 = new System.WinForms.PageSetupDialog ();
			this.mnuPaste = new System.WinForms.MenuItem ();
			this.mnuSetFontColor = new System.WinForms.MenuItem ();
			this.mnuSetBackCol = new System.WinForms.MenuItem ();
			this.mnuPrint = new System.WinForms.MenuItem ();
			this.mainMenu1 = new System.WinForms.MainMenu ();
			this.mnuCut = new System.WinForms.MenuItem ();
			this.mnuOpen = new System.WinForms.MenuItem ();
			this.mnuCopy = new System.WinForms.MenuItem ();
			this.mnuExit = new System.WinForms.MenuItem ();
			this.mnuUndo = new System.WinForms.MenuItem ();
			this.menuItem12 = new System.WinForms.MenuItem ();
			this.mnuSaveAs = new System.WinForms.MenuItem ();
			this.MnuTimeDate = new System.WinForms.MenuItem ();
			this.colorDialog1 = new System.WinForms.ColorDialog ();
			this.mnuFile = new System.WinForms.MenuItem ();
			this.mnuWordWrap = new System.WinForms.MenuItem ();
			this.menuItem5 = new System.WinForms.MenuItem ();
			this.saveFileDialog1 = new System.WinForms.SaveFileDialog ();
			this.menuItem7 = new System.WinForms.MenuItem ();
			this.menuItem6 = new System.WinForms.MenuItem ();
			this.menuItem9 = new System.WinForms.MenuItem ();
			this.mnuPageSetUp = new System.WinForms.MenuItem ();
			this.textBox1 = new System.WinForms.TextBox ();
			this.mnuEdit = new System.WinForms.MenuItem ();
			this.mnuSetFont = new System.WinForms.MenuItem ();
			this.fontDialog1 = new System.WinForms.FontDialog ();
			this.openFileDialog1 = new System.WinForms.OpenFileDialog ();
			this.mnuNew = new System.WinForms.MenuItem ();
			this.mnuDelete = new System.WinForms.MenuItem ();
			this.printDialog1 = new System.WinForms.PrintDialog ();
			this.mnuSelectAll = new System.WinForms.MenuItem ();
			this.menuItem2 = new System.WinForms.MenuItem ();
			this.mnuSave = new System.WinForms.MenuItem ();
			//@this.TrayHeight = 90;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			mnuAbout.Text = "&About";
			mnuAbout.Index = 0;
			mnuAbout.Click += new System.EventHandler (this.mnuAbout_Click);
			//@pageSetupDialog1.SetLocation (new System.Drawing.Point (107, 7));
			mnuPaste.Text = "&Paste";
			mnuPaste.Shortcut = System.WinForms.Shortcut.CtrlV;
			mnuPaste.Index = 4;
			mnuPaste.Click += new System.EventHandler (this.mnuPaste_Click);
			mnuSetFontColor.Text = "Set Font C&olor...";
			mnuSetFontColor.Index = 1;
			mnuSetFontColor.Click += new System.EventHandler (this.mnuFontColor_Click);
			mnuSetBackCol.Text = "Set &Background Color...";
			mnuSetBackCol.Index = 2;
			mnuSetBackCol.Click += new System.EventHandler (this.mnuSetBackCol_Click);
			mnuPrint.Text = "&Print";
			mnuPrint.Shortcut = System.WinForms.Shortcut.CtrlP;
			mnuPrint.Index = 6;
			mnuPrint.Click += new System.EventHandler (this.mnuPrint_Click);
			//@mainMenu1.SetLocation (new System.Drawing.Point (235, 7));
			mainMenu1.MenuItems.All = new System.WinForms.MenuItem[4] {this.mnuFile, this.mnuEdit, this.menuItem6, this.menuItem7};
			mnuCut.Text = "C&ut";
			mnuCut.Shortcut = System.WinForms.Shortcut.CtrlX;
			mnuCut.Index = 2;
			mnuCut.Click += new System.EventHandler (this.mnuCut_Click);
			mnuOpen.Text = "&Open...";
			mnuOpen.Shortcut = System.WinForms.Shortcut.CtrlO;
			mnuOpen.Index = 1;
			mnuOpen.Click += new System.EventHandler (this.mnuOpen_Click);
			mnuCopy.Text = "&Copy";
			mnuCopy.Shortcut = System.WinForms.Shortcut.CtrlC;
			mnuCopy.Index = 3;
			mnuCopy.Click += new System.EventHandler (this.mnuCopy_Click);
			mnuExit.Text = "E&xit";
			mnuExit.Shortcut = System.WinForms.Shortcut.AltF4;
			mnuExit.Index = 8;
			mnuExit.Click += new System.EventHandler (this.mnuExit_Click);
			mnuUndo.Text = "&Undo";
			mnuUndo.Shortcut = System.WinForms.Shortcut.CtrlZ;
			mnuUndo.Index = 0;
			mnuUndo.Click += new System.EventHandler (this.mnuUndo_Click);
			menuItem12.Text = "-";
			menuItem12.Index = 7;
			mnuSaveAs.Text = "Save &As...";
			mnuSaveAs.Index = 3;
			mnuSaveAs.Click += new System.EventHandler (this.mnuSaveAs_Click);
			MnuTimeDate.Text = "&Time/Date";
			MnuTimeDate.Shortcut = System.WinForms.Shortcut.F5;
			MnuTimeDate.Index = 8;
			MnuTimeDate.Click += new System.EventHandler (this.MnuTimeDate_Click);
			//@colorDialog1.SetLocation (new System.Drawing.Point (7, 7));
			mnuFile.Text = "&File";
			mnuFile.Index = 0;
			mnuFile.MenuItems.All = new System.WinForms.MenuItem[9] {this.mnuNew, this.mnuOpen, this.mnuSave, this.mnuSaveAs, this.menuItem9, this.mnuPageSetUp, this.mnuPrint, this.menuItem12, this.mnuExit};
			mnuWordWrap.Text = "&Word Wrap";
			mnuWordWrap.Index = 9;
			mnuWordWrap.Click += new System.EventHandler (this.mnuWordWrap_Click);
			menuItem5.Text = "-";
			menuItem5.Index = 6;
			//@saveFileDialog1.SetLocation (new System.Drawing.Point (331, 7));
			saveFileDialog1.Filter = "*.txt";
			saveFileDialog1.DefaultExt = "txt";
			saveFileDialog1.FileName = "doc1";
			saveFileDialog1.RestoreDirectory = true;
			menuItem7.Text = "&Help";
			menuItem7.Index = 3;
			menuItem7.MenuItems.All = new System.WinForms.MenuItem[1] {this.mnuAbout};
			menuItem6.Text = "&Tools";
			menuItem6.Index = 2;
			menuItem6.MenuItems.All = new System.WinForms.MenuItem[3] {this.mnuSetFont, this.mnuSetFontColor, this.mnuSetBackCol};
			menuItem9.Text = "-";
			menuItem9.Index = 4;
			mnuPageSetUp.Text = "Page Se&tup...";
			mnuPageSetUp.Index = 5;
			mnuPageSetUp.Click += new System.EventHandler (this.mnuPageSetUp_Click);
			textBox1.Multiline = true;
			textBox1.AutoSize = false;
			textBox1.TabIndex = 0;
			textBox1.Size = new System.Drawing.Size (440, 272);
			textBox1.TextChanged += new System.EventHandler (this.textBox1_TextChanged);
			mnuEdit.Text = "&Edit";
			mnuEdit.Index = 1;
			mnuEdit.MenuItems.All = new System.WinForms.MenuItem[10] {this.mnuUndo, this.menuItem2, this.mnuCut, this.mnuCopy, this.mnuPaste, this.mnuDelete, this.menuItem5, this.mnuSelectAll, this.MnuTimeDate, this.mnuWordWrap};
			mnuSetFont.Text = "Set &Font...";
			mnuSetFont.Index = 0;
			mnuSetFont.Click += new System.EventHandler (this.mnuSetFont_Click);
			//@fontDialog1.SetLocation (new System.Drawing.Point (7, 34));
			//@openFileDialog1.SetLocation (new System.Drawing.Point (446, 7));
			openFileDialog1.Filter = "*.txt";
			openFileDialog1.Title = "Open File";
			openFileDialog1.DefaultExt = "*.txt";
			openFileDialog1.RestoreDirectory = true;
			mnuNew.Text = "&New";
			mnuNew.Shortcut = System.WinForms.Shortcut.CtrlN;
			mnuNew.Index = 0;
			mnuNew.Click += new System.EventHandler (this.mnuNew_Click);
			mnuDelete.Text = "De&lete";
			mnuDelete.Shortcut = System.WinForms.Shortcut.Del;
			mnuDelete.Index = 5;
			mnuDelete.Click += new System.EventHandler (this.mnuDelete_Click);
			//@printDialog1.SetLocation (new System.Drawing.Point (103, 34));
			mnuSelectAll.Text = "Select &All";
			mnuSelectAll.Shortcut = System.WinForms.Shortcut.CtrlA;
			mnuSelectAll.Index = 7;
			mnuSelectAll.Click += new System.EventHandler (this.mnuSelectAll_Click);
			menuItem2.Text = "-";
			menuItem2.Index = 1;
			mnuSave.Text = "&Save";
			mnuSave.Shortcut = System.WinForms.Shortcut.CtrlS;
			mnuSave.Index = 2;
			mnuSave.Click += new System.EventHandler (this.mnuSave_Click);
			this.Text = "C# Note Book";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.Menu = this.mainMenu1;
			this.ClientSize = new System.Drawing.Size (472, 273);
			this.Resize += new System.EventHandler (this.Form1_Resize);
			this.Closing += new System.ComponentModel.CancelEventHandler (this.Form1_Closing);
			this.Controls.Add (this.textBox1);
		}

		 

		 

		protected void Form1_Resize (object sender, System.EventArgs e)
		{
			textBox1.Width =this.Width ; 
			textBox1.Height =this.Height ;
		}

		protected void mnuAbout_Click (object sender, System.EventArgs e)
		{
			Form abt=new about() ;
			abt.ShowDialog(); 
		}

		 

		protected void mnuSetBackCol_Click (object sender, System.EventArgs e)
		{
				colorDialog1.ShowDialog ();
				textBox1.BackColor  =colorDialog1.Color; 
		}

		protected void mnuFontColor_Click (object sender, System.EventArgs e)
		{
				colorDialog1.ShowDialog ();
				textBox1.ForeColor =colorDialog1.Color ; 
		}

		 

		protected void mnuSetFont_Click (object sender, System.EventArgs e)
		{
			fontDialog1.ShowDialog();
			textBox1.Font=fontDialog1.Font;
		}

		protected void mnuWordWrap_Click (object sender, System.EventArgs e)
		{
			textBox1.WordWrap = ! (textBox1.WordWrap); 
			mnuWordWrap.Checked  =! mnuWordWrap.Checked;
		}

		protected void MnuTimeDate_Click (object sender, System.EventArgs e)
		{
			textBox1.Text=textBox1.Text+DateTime.Now.ToLongTimeString()+DateTime.Now.ToLongDateString();
			textBox1.SelectionLength   = textBox1.Text.Length ;
			textBox1.SelectionStart = textBox1.Text.Length ;
		}

		protected void mnuSelectAll_Click (object sender, System.EventArgs e)
		{
			 textBox1.SelectAll ();			 
		}

		protected void mnuDelete_Click (object sender, System.EventArgs e)
		{
			 textBox1.SelectedText="";
		}

		protected void mnuCut_Click (object sender, System.EventArgs e)
		{
			 textBox1.Cut ();
		}

		protected void mnuUndo_Click (object sender, System.EventArgs e)
		{
			 textBox1.Undo();
		}

		protected void Form1_Closing (object sender, System.ComponentModel.CancelEventArgs e)
		{
			//check for unsaved data
			if (checkUnSavedData()==false)				
			{
				e.Cancel=true;
				return;
			}
			SaveSettings (); //Save setting to registry
		}

		protected void textBox1_TextChanged (object sender, System.EventArgs e)
		{
			blnSaveChkFlag=true;
		}
		

		protected void mnuPrint_Click (object sender, System.EventArgs e)
		{
			
			printDialog1.AllowPrintToFile =true;
			PrintDocument docPrn = new PrintDocument();
			docPrn.DocumentName=textBox1.Text;
			printDialog1.Document=docPrn;			
			if(printDialog1.ShowDialog()==DialogResult.OK)
			{
				try
				{
					docPrn.Print();
				}
				catch
				{
					MessageBox.Show ("Error While Printing", "Print Error");
				}
			}
			
		}

		protected void mnuPageSetUp_Click (object sender, System.EventArgs e)
		{
			PrintDocument docPrn = new PrintDocument();
			docPrn.DocumentName=textBox1.Text;
			pageSetupDialog1.Document=docPrn;
			pageSetupDialog1.ShowDialog();
		}

		protected void mnuSave_Click (object sender, System.EventArgs e)
		{
			SaveFile ();
		}

		protected void mnuExit_Click (object sender, System.EventArgs e)
		{
			//check for unsaved data
			if (checkUnSavedData())				
				this.Close();
		}

		 
		private bool SaveFile()
		{
			try
			{							
				string fName;
				DialogResult dlgR=saveFileDialog1.	ShowDialog ();
				if (dlgR == DialogResult.Cancel)
				{
					//Cancel
					blnSaveChkFlag=true;
					return false;
				}
				fName=saveFileDialog1.FileName ;
				StreamWriter fSave= new StreamWriter(fName);
				fSave.WriteLine(textBox1.Text);
				fSave.Flush();				
				fSave.Close(); 
				this.Text = fName;				
				blnSaveChkFlag=false;	
				return true;
			}
			catch
			{
				blnSaveChkFlag=true;
				return false;
			}
		}
		protected void mnuSaveAs_Click (object sender, System.EventArgs e)
		{
			//Save File
			SaveFile();
			
		}

		protected void mnuOpen_Click (object sender, System.EventArgs e)
		{
			if (checkUnSavedData())
			{			
					openFileDialog1.ShowDialog(); 			
					try
					{
						File f = new File (openFileDialog1.FileName);
						if (f.Exists)
							{
								StreamReader o = f.OpenText();
								textBox1.Text =o.ReadToEnd ();				
							}
						textBox1.SelectionStart =0;
						textBox1.SelectionLength =0;
						blnSaveChkFlag=false;
					} 
					catch
					{
						//Cancel Pressed
						blnSaveChkFlag=true;
					}
				}
			
						
		}

		protected void mnuPaste_Click (object sender, System.EventArgs e)
		{
			//Using Clipboard complex....U can use Paste method-One line statement
			// textBox1.Paste();

			/*******Using ClipBoard****************/
			//Declare an IDataObject to hold the data returned from the clipboard.
			//Then retrieve the data from the clipboard.

			IDataObject iData = Clipboard.GetDataObject();          
			//Determine whether the data is in a format you can use.
			if(iData.GetDataPresent(DataFormats.Text)) {
			//Yes it is, so display it in a text box.			
			textBox1.SelectedText =(String)iData.GetData(DataFormats.Text);			
	
			}
		}

		protected void mnuCopy_Click (object sender, System.EventArgs e)
		{
			Clipboard.SetDataObject (textBox1.SelectedText ,true);
		}

		private bool checkUnSavedData()
		{
			if (blnSaveChkFlag==true)
			{
				DialogResult dlgRes;
				dlgRes=MessageBox.Show( "The text in the file has changed. Do you want to save changes?","C# NotePad By Ajit",MessageBox.YesNoCancel);
				
				switch (dlgRes)				
				{
					case DialogResult.Yes :				
							
							return SaveFile();							
					case DialogResult.No :	
							blnSaveChkFlag=false;							
							return true;
					case DialogResult.Cancel :								
							return false;							
				}
			}
				return true;
		}

		protected void mnuNew_Click (object sender, System.EventArgs e)
		{
		
			//check for unsaved data
			if (checkUnSavedData())
			{
				textBox1.Clear ();	//textBox1.Text="";			
                blnSaveChkFlag=false;
                this.Text = "Untitled - C# NotePad";
			}
		}

		private void SaveSettings()		   
		{
			//Note I am not saving all properties of Font
			try
			{
				//Save final setting of notepad			
				RegistryKey reKSubKey = Registry.LocalMachine ;			
				reKSubKey.CreateSubKey ("AjitC#");
 
				//Font related
				reKSubKey.SetValue ("FontName",textBox1.Font.FontFamily.GetName(0));
				reKSubKey.SetValue ("FontSize", Convert.ToString(textBox1.Font.Size));
				
				//Fore Color
				reKSubKey.SetValue ("ForeCol", Convert.ToString(textBox1.ForeColor.ToARGB()));			
				
				//Back Col
				reKSubKey.SetValue ("BackCol",Convert.ToString(textBox1.BackColor.ToARGB ()));			
	 		}
			catch
			{
			}
		}
		private void GetSettings()
		{
			//Get last saved setting
			try
			{						
				RegistryKey reK = Registry.LocalMachine ;
				reK.OpenSubKey ("AjitC#");
				
				textBox1.Font =new System.Drawing.Font( reK.GetValue ("FontName").ToString() , Convert.ToSingle (reK.GetValue ("FontSize")));
				textBox1.ForeColor =System.Drawing.Color.FromARGB ((Convert.ToInt32 (reK.GetValue("ForeCol"))));
				textBox1.BackColor  =System.Drawing.Color.FromARGB ((Convert.ToInt32 (reK.GetValue("BackCol"))));			
			}
			catch
			{
				//Key may not present.Set default values
			}
			
		}

        
        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
			 
        }		
    }
}
