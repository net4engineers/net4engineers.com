namespace NotePad
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;

    /// <summary>
    ///    Summary description for about.
    /// </summary>
    public class about : System.WinForms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.WinForms.Button button1;
		private System.WinForms.Label label2;
		private System.WinForms.LinkLabel linkLabel1;
		private System.WinForms.Label label1;

        public about()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.label1 = new System.WinForms.Label ();
			this.label2 = new System.WinForms.Label ();
			this.button1 = new System.WinForms.Button ();
			this.linkLabel1 = new System.WinForms.LinkLabel ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			label1.Location = new System.Drawing.Point (54, 15);
			label1.Text = "C# Note Pad Created By";
			label1.Size = new System.Drawing.Size (189, 18);
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font ("Tahoma", 11, System.Drawing.FontStyle.Bold);
			label1.TabIndex = 0;
			label2.Location = new System.Drawing.Point (75, 56);
			label2.Text = "(ajit_mungale@hotmail.com)";
			label2.Size = new System.Drawing.Size (144, 13);
			label2.AutoSize = true;
			label2.TabIndex = 2;
			button1.Location = new System.Drawing.Point (111, 80);
			button1.DialogResult = System.WinForms.DialogResult.OK;
			button1.FlatStyle = System.WinForms.FlatStyle.Popup;
			button1.Size = new System.Drawing.Size (72, 24);
			button1.TabIndex = 3;
			button1.Text = "&OK";
			button1.Click += new System.EventHandler (this.button1_Click);
			linkLabel1.Cursor = System.Drawing.Cursors.Hand;
			linkLabel1.Text = "Ajit Mungale";
			linkLabel1.Size = new System.Drawing.Size (64, 13);
			linkLabel1.AutoSize = true;
			linkLabel1.TabIndex = 1;
			linkLabel1.TabStop = true;
			linkLabel1.Location = new System.Drawing.Point (115, 37);
			linkLabel1.LinkClick += new System.EventHandler (this.linkLabel1_LinkClick);
			this.Text = "About C# NotePad";
			this.MaximizeBox = false;
			this.StartPosition = System.WinForms.FormStartPosition.CenterParent;
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.BorderStyle = System.WinForms.FormBorderStyle.Fixed3D;
			this.TopMost = true;
			this.MinimizeBox = false;
			this.ClientSize = new System.Drawing.Size (294, 107);
			this.Controls.Add (this.button1);
			this.Controls.Add (this.label2);
			this.Controls.Add (this.linkLabel1);
			this.Controls.Add (this.label1);
		}

		protected void button1_Click (object sender, System.EventArgs e)
		{
			this.Close();
		}

		protected void linkLabel1_LinkClick (object sender, System.EventArgs e)
		{
			//mail to ajit
			System.Diagnostics.Process.Start("mailTo:ajit_mungale@hotmail.com");

		}
    }
}
